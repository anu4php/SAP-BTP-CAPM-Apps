sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    "./BaseController",
    "sap/ui/model/json/JSONModel"
], (Controller, MessageBox, BaseController, JSONModel) => {
    "use strict";

    return BaseController.extend("cmmportel.controller.Registration", {
        onInit: function () {
            var oModel = new sap.ui.model.json.JSONModel({
                isItemSelected: false 
            });
            this.getView().setModel(oModel);

            this._oWizard = this.getView().byId("idCompanyInfo"); 
            this._oModel = new sap.ui.model.json.JSONModel({
                isValid: false
            });
            this.getView().setModel(this._oModel, "wizardModel");
            
        },// Inside your controller
        onSubmit: function() {
            var firstName = this.byId("idFirst").getValue();
            var lastName = this.byId("idLast").getValue();
            var phoneNumber = this.byId("idPhone").getValue();
            var email = this.byId("idEmailAddress").getValue();
            var empName = this.byId("idEmpName").getValue();
            var empAddress = this.byId("idEmpAdd").getValue();
            var authSignatory = this.byId("_IDGenComboBox1").getSelectedKey();
        
            var payload = {
                //TypeOfRequest: this.byId("_IDGenComboBox").getSelectedKey(),
                firtName: firstName,
                lastName: lastName,
                phoneNumber: phoneNumber,
                emailID: email
                // EmployerName: empName,
                // EmployerAddress: empAddress,
                // AuthorizedSignatory: authSignatory
            };
        
            const oDataModel = this.getOwnerComponent().getModel();
            oDataModel.create("/requestor", payload, {
                success: function(oData, response) {
                    sap.m.MessageToast.show("Request submitted successfully");
                },
                error: function(oError) {
                    sap.m.MessageToast.show("Error in submission");
                }
            });
        },        

        onItemPress: function (oEvent) {
            var oItem = oEvent.getSource();
            var oVBox = oItem.getAggregation("content")[0];
            var oTitle = oVBox.getItems()[0];
            var sTitle = oTitle.getText();
            if (sTitle) {
                this.getView().getModel().setProperty("/isItemSelected", true);
            } else {
                this.getView().getModel().setProperty("/isItemSelected", false);
            }
        },

    additionalInfoValidation: function () {
    var oView = this.getView();
    var aInputs = [
        oView.byId("idFirst"),
        oView.byId("idLast"),
        oView.byId("idPhone"),
        oView.byId("idEmailAddress"),
        oView.byId("idEmpName"),
        oView.byId("idEmpAdd")
    ];
    var oWizardModel = this.getView().getModel("wizardModel");
    oWizardModel.setProperty("/isValid", false);

    aInputs.forEach(function (oInput) {
        oInput.attachChange(function () {
            var bValidationError = false;
            aInputs.forEach(function (input) {
                if (!input.getValue()) {
                    input.setValueState("Error");
                    input.setValueStateText("This field is required");
                    bValidationError = true; 
                } else {
                    input.setValueState("None");
                }
            });

            oWizardModel.setProperty("/isValid", !bValidationError);
            if (bValidationError) {
                sap.m.MessageToast.show("Please fill all required fields before proceeding.");
            }
        }, this);  
    });
},
onAddItem: function () {
    var oTable = this.getView().byId("idTableAddOper"); 
    var oDeleteButton = this.getView().byId("idDelteItem"); 
    
    if (!oTable) {
        console.error("Table not found. Ensure the fragment is properly loaded.");
        return;
    }
    var oNewItem = new sap.m.ColumnListItem({
        type: "Active",
        cells: [
            new sap.m.Input({ required: true, editable: false }),
            new sap.m.Input({ required: true, editable: false }),
            new sap.m.Input({ required: true, editable: true }),
            new sap.m.Input({ required: true, editable: true }),
            new sap.m.Input({ required: true, editable: true }),
            new sap.m.DatePicker({})
        ]
    });

    // Add the new row to the table
    oTable.addItem(oNewItem);

    // Ensure the Delete button is visible after adding a new row
    if (oDeleteButton) {
        oDeleteButton.setVisible(true);
    }
},

onDeleteItem: function () {
    var oTable = this.getView().byId("idTableAddOper"); // Get Table Reference
    var oDeleteButton = this.getView().byId("idDelteItem"); // Get Delete Button Reference
    
    if (!oTable) {
        console.error("Table not found. Ensure the fragment is properly loaded.");
        return;
    }

    var aItems = oTable.getItems(); // Get all table rows

    if (aItems.length > 1) {
        // Remove the last added row
        oTable.removeItem(aItems[aItems.length - 1]);
    }

    // Hide the Delete button if only one row remains
    if (aItems.length === 2 && oDeleteButton) {
        oDeleteButton.setVisible(false);
    }
},
handleNavigationChange: function (oEvent) {
    var oWizard = this.byId("idCreateProductWizard");
    var oStep = oEvent.getParameter("step");
    
    // Enable previous button if not on first step
    if (oWizard.getSteps().indexOf(oStep) > 0) {
        oWizard.setShowPreviousButton(true);
    } else {
        oWizard.setShowPreviousButton(false);
    }
},
onNavigateToTopHeader: function () {
    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
    oRouter.navTo("TargetTopHeader", {
        TopHeader: "default"  // Provide a valid value for the parameter
    });
},   

    });
});