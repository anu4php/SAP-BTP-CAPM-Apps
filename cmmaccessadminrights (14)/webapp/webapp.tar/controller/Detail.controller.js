sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/mvc/Controller",
	"sap/m/Dialog",
	"sap/m/DatePicker",
	"sap/m/Select",
	"sap/m/Label",
	"sap/m/CheckBox",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/Item",
	"sap/m/Text",
	"sap/m/Button",
	"sap/ui/layout/form/SimpleForm",
	"sap/ui/Device"
], function (JSONModel, Controller, Dialog,
	DatePicker,
	Select,
	Label,
	CheckBox,
	MessageToast,
	MessageBox,
	Item,
	Text,
	Button,
	SimpleForm,
	Device) {
	"use strict";

	return Controller.extend("cmmaccessadminrights.controller.Detail", {
		
		onInit: function () {
			var oExitButton = this.getView().byId("exitFullScreenBtn"),
				oEnterButton = this.getView().byId("enterFullScreenBtn");

			this.oRouter = this.getOwnerComponent().getRouter();
			this.oModel = this.getOwnerComponent().getModel();
			
			this.oRouter.getRoute("detail").attachPatternMatched(this._onProductMatched, this);
			//this.oRouter.getRoute("list").attachPatternMatched(this._onProductMatched, this);
			this.oTabPath;
			
		},
		
		handleFullScreen: function () {
			this.bFocusFullScreenButton = true;
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.oRouter.navTo("detail", {layout: sNextLayout, oBPid: this._oBPid, oTabPath: this.oTabPath});
		},
		handleExitFullScreen: function () {
			this.bFocusFullScreenButton = true;
			var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/exitFullScreen");
			this.oRouter.navTo("detail", {layout: sNextLayout, oBPid: this._oBPid, oTabPath: this.oTabPath});
		},
		handleClose: function () {
			const oRouter = this.getOwnerComponent().getRouter();
			const bIsPhone = sap.ui.Device.system.phone; // Works even in browser device emulation
		  
			let sLayout = "OneColumn"; // default for phone
		  
			if (!bIsPhone) {
			  // Use semantic helper layout for larger devices
			  const oFCL = this.getView().getParent().getParent();
			  const sNextLayout = oFCL.getModel().getProperty("/actionButtonsInfo/midColumn/closeColumn");
			  sLayout = sNextLayout || "OneColumn";
			}
			console.log(this._oBPid,"detailsoRouter>>>", this.oTabPath);
		  
			oRouter.navTo("list", {
			  layout: sLayout,
			  oBPid: this._oBPid || 0,
			  tab: this.oTabPath || "enerlineUsers"
			});
			//Working Button Back
			/*const oHistory = sap.ui.core.routing.History.getInstance();
			const sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("list", {
				layout: sap.f.LayoutType.OneColumn
				}, true);
			}*/
			//end working back button
			console.log('handleClose', this.oTabPath);
			//close button action
			//const oRouter = this.getOwnerComponent().getRouter();
			//	const oFCL = sap.ui.core.Component.getOwnerComponentFor(this.getView()).byId("fcl");

				// Optional: set layout manually in UI
			//	oFCL.setLayout(sap.f.LayoutType.OneColumn); // or TwoColumnsBeginExpanded
				
				// Also update the route in URL
				/*oRouter.navTo("list", {
					layout: sap.f.LayoutType.OneColumn,
					tab: this.oTabPath || "enerlineUsers" // or LayoutType.TwoColumnsBeginExpanded
				}, true); */// replace URL instead of pushing history
				//end close
			},

		// Button Handlers for "Export Selected", "Terminate All Access", and "Submit Changes"
		onExportSelectedPress: function () {
			const oContext = this.getOwnerComponent().getModel("usersRights").getData(); // or undefined for default model
			const accessData = oContext[this.oTabPath].access;
			const oUsersModel = this.getOwnerComponent().getModel("usersList").getData();
			const sUserName = oUsersModel[this.oTabPath][this._oBPid].name;
			const rolesNew = this.getOwnerComponent().getModel("cmmAccessRights").getData().cmmRoles;
		   
			// CSV Header
			let csvContent = "Category,Access Right,Effective Date,End Date\n";
		   
			(rolesNew || []).forEach(function (category) {
			  const catName = category.categoryName;
			  const userRights = accessData[catName] || [];
		   
			  (category.accessRights || []).forEach(function (right) {
				const matchingRight = userRights.find(data => data.title === right.rightName);
				const isSelected = !!matchingRight;
				const effectiveDate = matchingRight ? matchingRight.effectiveDate : "";
				const endDate = matchingRight ? matchingRight.endDate : "";
		   
				// Only export selected rights
				if (isSelected) {
				  const row = `"${catName}","${right.rightName}","${effectiveDate}","${endDate}"\n`;
				  csvContent += row;
				}
			  });
			});
		   
			// Create and trigger CSV download
			const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
			const link = document.createElement("a");
			const filename = `${sUserName}_access_export.csv`;
			link.setAttribute("href", URL.createObjectURL(blob));
			link.setAttribute("download", filename);
			link.style.visibility = "hidden";
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		  },
		
		  onExportAllPress: function () {
			//get Table data
			this._oBPid = this._oBPid || "0";
			const oPath = this.oTabPath;
			
			//const oContext = this.getOwnerComponent().getModel("usersRights").getData(); // or undefined for default model
			//const accessData = oContext[this.oTabPath].access;
			const oUsersModel = this.getOwnerComponent().getModel("usersList").getData();
			
			//const oModelData = oPath;
			const oUserData = oUsersModel[this.oTabPath];
			const accessData=oUserData.access;
			//end table data
			const sUserName = "allUsers"; // optional: fallback name
			// CSV Header
			let csvContent = "User Name,Category,Access Right,Effective Date,End Date\n";
		   
			oUserData.forEach(function (user) {
			  const userName = user.name;
			  const access = user.access || [];
				Object.keys(access).forEach(function (category) {
				const rights = access[category];
				rights.forEach(function (right) {	
				// Only export selected rights
				
				  const row = `"${userName}","${category}","${right.title}","${right.effectiveDate}","${right.endDate}"\n`;
				  csvContent += row;
				
				});
			  });
			});
		   
			// Create and trigger CSV download
			const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
			const link = document.createElement("a");
			const filename = `${sUserName}_access_export.csv`;
			link.setAttribute("href", URL.createObjectURL(blob));
			link.setAttribute("download", filename);
			link.style.visibility = "hidden";
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		  },

		  onTerminateAllAccessPress234: function () {
			// Logic for terminating all access for the selected user
			const oUserList = this.byId("userList");
			const oSelectedItem = oUserList.getSelectedItem();
			if (!oSelectedItem) {
			  sap.m.MessageToast.show("Please select a user to terminate all access.");
			  return;
			}
	  
			const oUser = this.getView().getModel("usersModel").getProperty(oSelectedItem.getBindingContext("usersModel").getPath());
	  
			// Assuming access data is an object and we clear it
			oUser.access = {};
			this.getView().getModel("usersModel").refresh();
	  
			sap.m.MessageToast.show("All access terminated for " + oUser.name);
		  },

		  getAccessMappings: function (oUserData, cmmRoles, sDate) {
			const aResult = [];
		  
			for (const [sCategoryName, aRightsArray] of Object.entries(oUserData)) {
			  // Find matching category from cmmRoles
			  const oCategory = cmmRoles.find(role => role.categoryName === sCategoryName);
			  if (!oCategory) {
				console.warn(`Category not found in cmmRoles: ${sCategoryName}`);
				continue;
			  }
		  
			  for (const oRightEntry of aRightsArray) {
				const sAccessRightID = oRightEntry.AccessRight_ID;
		  
				// Find access right in that category
				const oAccessRight = oCategory.accessRights.find(
				  right => right.accessTypeID === sAccessRightID
				);
		  
				if (!oAccessRight) {
				  console.warn(`Access right not found for ID ${sAccessRightID} in category ${sCategoryName}`);
				  continue;
				}
		  
				// Push final mapping
				aResult.push({
				  categoryID: oCategory.categoryID,
				  accessTypeID: oAccessRight.accessTypeID,
				  Date: sDate,
				  ID: oRightEntry.id,
				  /*title: oRightEntry.title,
				  effectiveDate: oRightEntry.effectiveDate || null,
				  endDate: oRightEntry.endDate || null,
				  selected: oRightEntry.selected ?? true*/
				});
			  }
			}
		  
			return aResult;
		  },

		  onTerminateAllAccessPress: async function () {
			const that = this;
			const oAccessModel = this.getOwnerComponent().getModel("cmmAccessRights");
			const oPath = this.oTabPath || "enerlineUsers";
			const sPath = "/" + oPath + "/" + this._oBPid;
			//const oUserData = oAccessModel.getProperty(sPath);

			const oTrmType = oPath === "enerlineUsers"? "I" : "A";
			const oUsersModel = this.getOwnerComponent().getModel("usersList").getData();
			const oUserData = oUsersModel[this.oTabPath][this._oBPid];
			const sUserName = oUserData?.name; // optional: fallback name

			const oContext = this.getOwnerComponent().getModel("usersRights").getData(); 
			const accessData = oContext[oPath].access;
			const oTrmAccessRights = accessData;
			
			const oRoleIds = oAccessModel.getProperty("/cmmRoles");
			console.log(oTrmAccessRights, "accessRightsIDDD:", oRoleIds);
			

			//console.log("accessRightsIDDD:", aMappedAccess);
			//console.log(oDatainfo, "terminate - Acc", accessData);
			//const sUserName = "Prabhakaran Manokaran";
			const sCompanyName = "A.E. Sharp Ltd.";
	   
			const oDatePicker = new DatePicker({
			  valueFormat: "yyyy-MM-dd",
			  displayFormat: "long",
			  width: "100%",
			  required: true
			});
	   
			const oTerminationType = new Select({
			  width: "100%",
			  required: true,
			  selectedKey: "",
			  items: [
				new Item({ text: "Please select", key: "" }),
				new Item({ text: `Terminate Enerline Access, ${sUserName}`, key: "TEA" }),
				new Item({ text: `Terminate Enerline Access and Terminate Relationship, ${sUserName}`, key: "TER" })
			  ]
			});
	   
			const oAcknowledge = new CheckBox({
			  selected: false,
			  text: `I acknowledge that after clicking on the submit button, ${sUserName} will no longer be able to log into Enerline on behalf of ${sCompanyName} on the effective date shown above.`,
			  wrapping: true
			});
	   
			const oForm = new SimpleForm({
			  layout: "ResponsiveGridLayout",
			  editable: true,
			  labelSpanM: 4,
			  content: [
				new Text({
				  text: `This action will terminate all Enerline access for ${sUserName} on behalf of ${sCompanyName}.`,
				  wrapping: true
				}),
				new Label({ text: "Effective Date *" }),
				oDatePicker,
				new Label({ text: "Termination Type *" }),
				oTerminationType,
				oAcknowledge
			  ]
			});
	   
			const oDialog = new Dialog({
			  title: "Terminate all Access",
			  icon: "sap-icon://confirm",
			  type: "Message",
			  state: "Success",
			  class: "otermallaccess",
			  contentWidth: "550px",
			  content: [oForm],
			  beginButton: new Button({
				text: "Submit",
				type: "Emphasized",
				press: async function (oEvent) {
				  oDialog.addStyleClass("sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer");
				  const bValid = oDatePicker.getValue() && oTerminationType.getSelectedKey() && oAcknowledge.getSelected();
				  const sDate = oDatePicker.getValue();
				  const sType = oTerminationType.getSelectedKey();
				  const bConfirmed = oAcknowledge.getSelected();
				  console.log('Submit Requst', bValid);	
				  
				 /* const aCells = oItem.getCells();
				  const oCheckbox = aCells[0];
				  const aCustomData = oCheckBox.getCustomData();
				  const oCheckBPid = aCustomData.find(cd => cd.getKey()=== "id")?.getValue();*/

				  const aMappedAccess = that.getAccessMappings(oTrmAccessRights, oRoleIds, sDate);
				  console.log('aMappedAccess', aMappedAccess);

				  // Validation
				  if (!sDate || !sType || !bConfirmed) {
					  MessageBox.warning("Please complete all required fields.");
					  return;
				  }
			   
				  // ✅ Create payload
				  const oPayloadTerm = {
					  ID: crypto.randomUUID(),
					  BPId: oUserData?.bpNumber,  
					  Name: sUserName,
					  AccessType: oTrmType,
					  Date: sDate,
					  TerminationType: sType,
					  TerminationType_text: "true",
					  RelationBP: oUserData?.relationBP,
					  Status: "Active"
				  };
				 
				 const oModel = that.getView().getModel("mainModel");
				 console.log(oModel instanceof sap.ui.model.odata.v4.ODataModel); // true or false
  					
					try {						
						
						const oBinding = oModel.bindList("/BPAccessTermination", undefined, undefined, undefined, {
							$$groupId: "submitGroup"
						  });
						  await oBinding.create(oPayloadTerm);
					
					for (const access of aMappedAccess) {
						const sUpdatePath = `/BPAccessRights(ID='${access.ID}')`; // Use key-based URL format
					  
						const oContextBinding = oModel.bindContext(sUpdatePath, null, {
						  $$groupId: "submitGroup"
						});
					  
						const oBoundContext = oContextBinding.getBoundContext();
						if (oBoundContext) {
						  // Update the property/field (like endDate or accessStatus)
						  oBoundContext.setProperty("endDate", sDate);  // or any other field you need
						} else {
						  console.warn("Failed to bind context for ID:", access.ID);
						}
					  }
					//oBoundContext.getBinding().setUpdateGroupId("submitGroup");
					if ( sType === "TER" ) { 
						
						const oFetchUpdate = oPath === "enerlineUsers"? await that.getUserCompanyDt(oUserData?.bpNumber, oUserData?.relationBP, sDate) : await that.getAgentCompanyDt(oUserData?.bpNumber, oUserData?.relationBP, sDate);

					} 
					
						oDialog.close();
						
						const oDialogSuc = new sap.m.Dialog({
							type: "Message",
							draggable: false,
							resizable: false,
							contentWidth: "40%",
							title: "Request received",
							icon: "sap-icon://message-success", 
							content: new sap.m.Text({
							  text: `Your changes have been saved. Users affected by the change may need to log out of Enerline in order to activate the changes.\n\nThank you for using Enerline.`
							}),
							beginButton: new sap.m.Button({
							  text: "Close",
							  press: function () {
								oDialogSuc.close();
								
							  }
							})
						  });
						  

						  // Submit all
					try {
						
						await oModel.submitBatch("submitGroup");
						await oModel.refresh();
						
						const oAccessModel = that.getOwnerComponent().getModel("usersRights");
						oAccessModel.refresh(true);
						await that._onProductMatched(that._reloadRouteEvent());
						oDialogSuc.open();
					  } catch (err) {
						console.error("Submission failed:", err);
						sap.m.MessageToast.show("Failed to submit changes.");
					  }
						//MessageBox.success("Please complete all required fields.");
					} catch (err) {
						console.error("Create failed", err);
					}
				
				}
			  }),
			  endButton: new Button({
				text: "Cancel",
				press: function () {
				  oDialog.close();
				}
			  })
			  
			});
	   
			oDialog.open();
		  },

		  getAgentCompanyDt: async function (bpNumber, relationBP, sDate) {
			const that = this;
			//const oModel = that.getModel("mainModel"); // or your relevant model
			const oModel = that.getView().getModel("mainModel");
			const oFilter1 = new sap.ui.model.Filter("AgentBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, bpNumber);
			const oFilter2 = new sap.ui.model.Filter("ContractHolderBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, relationBP);
			// Combine filters with AND
			const userFilter = new sap.ui.model.Filter([oFilter1, oFilter2], true); // `true` = AND
			// Bind list with filter
			const oBindAGVal = oModel.bindList("/AgentCompanies", undefined, undefined, userFilter);
			try {
			const aContexts = await oBindAGVal.requestContexts();
			const aResults = aContexts.map(ctx => ctx.getObject());
			console.log("Read AgentCompanies:", aResults[0].ValidFrom);
			const sUpdatePathC = `/AgentCompanies(AgentBP_BusinessPartnerID='${bpNumber}',ContractHolderBP_BusinessPartnerID='${relationBP}',ValidFrom=${aResults[0].ValidFrom})`;
			const oContextBindingC = oModel.bindContext(sUpdatePathC, null, {
			$$groupId: "submitGroup"
			});
			const oBoundContextC = oContextBindingC.getBoundContext();
			
			if (oBoundContextC) {
			oBoundContextC.setProperty("ValidTo", sDate);
			}
			await oModel.submitBatch("submitGroup");
			return aResults;
			
			} catch (err) {
			console.error("Error reading AgentCompanies:", err);
			}
		  },
		  getUserCompanyDt: async function (bpNumber, relationBP, sDate) {
			const that = this;
			//const oModel = that.getModel("mainModel"); // or your relevant model
			const oModel = that.getView().getModel("mainModel");
			const oFilter1 = new sap.ui.model.Filter("ContactBP_ContactBP", sap.ui.model.FilterOperator.EQ, bpNumber);
			const oFilter2 = new sap.ui.model.Filter("CompanyBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, relationBP);
			// Combine filters with AND
			const userFilter = new sap.ui.model.Filter([oFilter1, oFilter2], true); // `true` = AND
			// Bind list with filter
			const oBindAGVal = oModel.bindList("/UserCompanies", undefined, undefined, userFilter);
			try {
			const aContexts = await oBindAGVal.requestContexts();
			const aResults = aContexts.map(ctx => ctx.getObject());
			console.log("Read UserCompanies:", aResults[0].ValidFrom);
			const sUpdatePathA = `/UserCompanies(ContactBP_ContactBP='${bpNumber}',CompanyBP_BusinessPartnerID='${relationBP}',ValidFrom=${aResults[0].ValidFrom})`;
			const oContextBindingA = oModel.bindContext(sUpdatePathA, null, {
			$$groupId: "submitGroup"
			});
			const oBoundContextA = oContextBindingA.getBoundContext();
			if (oBoundContextA) {
			oBoundContextA.setProperty("ValidTo", sDate);
			}
			await oModel.submitBatch("submitGroup");
			return aResults;
			} catch (err) {
			console.error("Error reading AgentCompanies:", err);
			}
		  },
		 
		  onSubmitChangesPress: async function () {
			try {
			 // alert("✅ Submit triggered");
			  const oMainModel = this.getView().getModel("mainModel");
			  const oAccessModel = this.getOwnerComponent().getModel("cmmAccessRights");
			  const oPath = this.oTabPath || "enerlineUsers";
			  const sPath = "/" + oPath + "/" + this._oBPid;
			  const oUserDataright = oAccessModel.getProperty(sPath);

			  const oUsersModel = this.getOwnerComponent().getModel("usersList").getData();
			  const oUserData = oUsersModel[this.oTabPath][this._oBPid];

			  const oContext = this.getOwnerComponent().getModel("usersRights").getData(); 
			  const accessData = oContext[oPath].access;
		  
			  const getDateValue = (oControl) => {
				if (oControl instanceof sap.m.Input) return oControl.getValue();
				if (oControl instanceof sap.m.Text) return oControl.getText();
				return null;
			  };
		  
			  const oOldRights = accessData;
			  const oTableContainer = this.byId("accessContainer2");
			  const aPanels = oTableContainer.getItems();
		  
			  const aNewCreates = [];
			  const aUpdates = [];
			  const aDeselected = [];
			  let bInputChangedWithoutCheckbox = false;
		  
			  for (const oPanel of aPanels) {
				//const sCategory = oPanel.getHeaderText();
				
				
				const oHeaderHBox = oPanel.getHeaderToolbar().getContent()[0]; // HBox
				// Get the Title control from the HBox
				const oTitle = oHeaderHBox.getItems()[0]; // sap.m.Title
				// Get the text from the Title
				const sCategory = oTitle.getText();
				
				const oTable = oPanel.getContent()[0];
				const aItems = oTable.getItems();
		  
				for (const oItem of aItems) {
				  const [oCheckBox, oEffectiveDateCtrl, oEndDateCtrl] = oItem.getCells();
				  const sRightName = oCheckBox.getProperty("text");
				  const oCategory = oAccessModel.getProperty("/cmmRoles").find(cat => cat.categoryName === sCategory);
				  const oRight = oCategory?.accessRights.find(r => r.rightName === sRightName);
				  const sCategoryId = oCategory?.categoryID;
				  const oRightID = oRight.accessTypeID;
		  
				  const bSelected = oCheckBox.getSelected();
				  const sEffectiveDate = getDateValue(oEffectiveDateCtrl);
				  const sEndDate = getDateValue(oEndDateCtrl);
		  
				  const oCheckBPid = oCheckBox.getCustomData().find(cd => cd.getKey() === "id")?.getValue();
				  const oOldEntry = oOldRights[sCategory]?.find(a => a.id === oCheckBPid);
		  
				  // CREATE
				  if (bSelected && !oOldEntry) {
					console.log("📌 Preparing CREATE:", sRightName, sEffectiveDate, sEndDate);
					aNewCreates.push({
					  ID: crypto.randomUUID(),
					  BPNumber: oUserData.bpNumber,
					  RelationBP_BusinessPartnerID: oUserData.relationBP,
					  AccessRights_accessRightType_code: sCategoryId,
					  AccessRights_code: oRightID,
					  startDate: sEffectiveDate,
					  endDate: sEndDate
					});

					
				  }
				  // UPDATE
				  else if (bSelected && oOldEntry) {
					const isStartDateChanged = oOldEntry.effectiveDate !== sEffectiveDate;
					const isEndDateChanged = oOldEntry.endDate !== sEndDate;
					if ((isStartDateChanged && sEffectiveDate) || (isEndDateChanged && sEndDate)) {
					  console.log("✏️ Preparing UPDATE:", oCheckBPid, sEffectiveDate, sEndDate);
					  aUpdates.push({
						ID: oCheckBPid,
						startDate: sEffectiveDate,
						endDate: sEndDate
					  });
					}
				  }
				  // DESELECTED
				  else if (!bSelected && oOldEntry) {
					
					aDeselected.push({
					  ID: oCheckBPid,
					  endDate: sEndDate || new Date().toISOString().split("T")[0],
					  status: "deactivated"
					});
					//console.log('aDeselected', aDeselected);
					//console.log("❌ Preparing DEACTIVATE:", oCheckBPid);
				  }

				  
		  
				  // VALIDATION: input changed but checkbox not selected
				  if (!bSelected && (!oOldEntry || oOldEntry.effectiveDate !== sEffectiveDate || oOldEntry.endDate !== sEndDate)) {
					if ((sEffectiveDate && sEffectiveDate !== "") || (sEndDate && sEndDate !== "")) {
					  bInputChangedWithoutCheckbox = true;
					}
				  }
				}
			  }
		  
			  if (aNewCreates.length === 0 && aUpdates.length === 0 && aDeselected.length === 0) {
				//sap.m.MessageBox.error("Please select the checkbox to save changes.");
				this._showMessageDialog("Error", "Please select the checkbox to save changes.");
				return;
			  }
		  
			 /* if (bInputChangedWithoutCheckbox && aDeselected.length === 0) {
				sap.m.MessageBox.error("Please select the checkbox for the modified access right(s).");
				return;
			  }*/
			  // Log changes
				console.log("✅ New Creates:", aNewCreates);
				console.log("✏️ Updates (changed dates):", aUpdates);
				console.log("❌ Deselected:", aDeselected);
			  // CREATE
			  if (aNewCreates.length > 0) {
			  for (const createObj of aNewCreates) {
				try {
				  const oBinding = oMainModel.bindList("/BPAccessRights", undefined, undefined, undefined, {
					$$groupId: "submitGroup"
				  });
				  oBinding.create(createObj);
				} catch (e) {
				  console.error("❌ CREATE failed:", e);
				}
			  }
			}
			  // UPDATE
			  if (aUpdates.length > 0) {
			  for (const updateObj of aUpdates) {

				try {
					const sUpdatePath = `/BPAccessRights(ID='${updateObj.ID}')`;
				
				const oContextBinding = oMainModel.bindContext(sUpdatePath, null, {
				  $$groupId: "submitGroup"
				});
			  
				const oBoundContext = oContextBinding.getBoundContext();
			  
				if (oBoundContext) {
					const oSTdate = updateObj? `${updateObj.startDate}` : null;
					const oEDdate = updateObj? `${updateObj.endDate}` : null;
					//const oEdr = oEDdate ? oEDdate === "" : null;
					const oSTdr = oSTdate && oSTdate === "" ? null : oSTdate;
					const oEdr = oEDdate && oEDdate === "" ? null : oEDdate;
					console.log(oEdr);
					console.log(oSTdr,'HHHHH',oEdr);
					if (oSTdr === "" || oSTdr.trim() === "") {
						console.log("wrong come hereSt");
						oBoundContext.setProperty("startDate", null);
					  } else {
						console.log("St date here");
						oBoundContext.setProperty("startDate", oSTdr);
					  }
					  console.log(oEdr,' tessfds', oEdr.trim());
					  if (oEdr === ""  || oEdr.trim() === "" || oEdr === null) {
						console.log("wrong come here");
						oBoundContext.setProperty("endDate", null);
					  } else {
						console.log("come here");
						oBoundContext.setProperty("endDate", oEDdate);
						
					  }
					
				} else {
				  console.warn("⚠️ No bound context found for update path:", sUpdatePath);
				}
					

				} catch (e) {
					console.error("❌ UPDATE failed for ID:", updateObj.ID, e);
				}
			}

			  }//if update length check
		  
			  // DEACTIVATE
			  if (aDeselected.length > 0) {
			  for (const deactivated of aDeselected) {
				try {
				  console.log("⏳ Deactivating ID:", deactivated.ID);
				
				 
				console.log("its coming here333");

					const sUpdatePath = `/BPAccessRights(ID='${deactivated.ID}')`; // Use key-based URL format
					  
						const oContextBinding = oMainModel.bindContext(sUpdatePath, null, {
						  $$groupId: "submitGroup"
						});
					  
						const oBoundContext = oContextBinding.getBoundContext();
						if (oBoundContext) {
						  // Update the property/field (like endDate or accessStatus)
						 // oBoundContext.setProperty("endDate", deactivated.endDate);  // or any other field you need
						  oBoundContext.setProperty("startDate", null);
						  oBoundContext.setProperty("endDate",  null);
						  // oBoundContext.setProperty("status", "deactivated");
						} else {
						  console.warn("Failed to bind context for ID:", deactivated.endDate);
						}
					  
			  
				} catch (error) {
				  console.error("❌ Error during deactivation:", deactivated.ID, error);
				}
			   }
			  }//if deactivated length check
		  
			  // SUBMIT
			  console.log("Submitting all changes...");
			  try {
				await oMainModel.submitBatch("submitGroup");
				await oMainModel.refresh();
				//this._onProductMatched();
				//await this._onSelectUserAccess(this._oBPid, this.oTabPath);
				console.log("Batch submitted");
				const oAccessModelc = this.getOwnerComponent().getModel("usersRights");
  				oAccessModelc.refresh(true);
				  await this._onProductMatched(this._reloadRouteEvent());
				//sap.m.MessageBox.success("Access rights changes submitted successfully.");
				this._showMessageDialog("Success", "Access rights changes submitted successfully.");

				/*setTimeout(() => {
					//const oRouter = this.getOwnerComponent().getRouter();
				  
					this.getOwnerComponent().getRouter().navTo("detail", {
						layout: "TwoColumnsMidExpanded",
						oBPid: this._oBPid,
					  oTabPath: this.oTabPath
					}, true); // 🔁 reload current mid column view
				  }, 100);*/
			  } catch (err) {
				console.error("Batch submission failed:", err);
				//sap.m.MessageBox.error("Failed to submit access right changes.");
				/*setTimeout(() => {
					sap.m.MessageBox.error("Failed to submit access right changes.");
				  }, 0);*/

				  this._showMessageDialog("Error", "Failed to submit access right changes");
				  
			  }
		  
			} catch (outerErr) {
			  console.error("Something went wrong in submitChanges handler:", outerErr);
			  //sap.m.MessageBox.error("Unexpected error during submission. Check console logs.");
			  this._showMessageDialog("Error", "Unexpected error during submission. Check console logs.");
			}
		  },
		  //Reloading submit actions
		  _reloadRouteEvent: function () {
			return {
			  getParameter: function (sParam) {
				if (sParam === "arguments") {
				  return {
					oBPid: this._oBPid,
					oTabPath: this.oTabPath
				  };
				}
				return null;
			  }.bind(this), // Important to bind 'this' context!
			  getParameters: function () {
				return {
				  arguments: {
					oBPid: this._oBPid,
					oTabPath: this.oTabPath
				  }
				};
			  }.bind(this)
			};
		  },

		  //Message Poupover
		  _showMessageDialog: function (sType, sMessage, sTitle = "") {
			const oDialog = new sap.m.Dialog({
			  title: sTitle || (sType === "Success" ? "Success" : "Error"),
			  type: "Message",
			  state: sType, // "Success" or "Error" or "Warning" or "Information"
			  content: new sap.m.Text({ text: sMessage }),
			  beginButton: new sap.m.Button({
				text: "OK",
				press: function () {
				  oDialog.close();
				}
			  })
			});
			oDialog.open();
		  },
		  //message end

		  onUpdatePatchTest: async function () {
			const oModel = this.getView().getModel("mainModel");
		  
			const sID = "57ce39b8-c3c5-4227-bbf5-cb163284519b"; // Replace with real UUID
			const sPath = `/BPAccessRights(ID='${sID}')`;
			const sNewDate = "2025-08-01";
		  
			const oContext = oModel.bindContext(sPath, null, {
			  $$groupId: "submitGroup"
			});
		  
			await oContext.requestObject();
		  
			// ✅ Use setProperty on model with context
			oModel.setProperty("endDate", sNewDate, oContext);
		  
			// ✅ Confirm pending changes
			console.log("Has pending changes:", oModel.hasPendingChanges()); // must be true
		  
			try {
			  await oModel.submitBatch("submitGroup");
			  console.log("✅ PATCH sent to backend!");
			} catch (err) {
			  console.error("❌ PATCH failed:", err);
			}
		  },
		  
		  // 🧩 Simple UID generator
		  _generateUID: function () {
			return "ID-" + Date.now();
		  },
		onListItemPress: function (oEvent) {
			const oItem = oEvent.getParameter
			  ? oEvent.getParameter("listItem")
			  : oEvent; // fallback if passed directly
	  
			if (!oItem) return;
	  
			const sPath = oItem.getBindingContext("cmmAccessRights").getPath();
			const oUser = this.getView().getModel("usersRights").getProperty(sPath);
	  
			if (oUser) {
			  this.byId("detailPage").setTitle("Access for " + oUser.name);
			  this._renderAccess(oUser.access);
			}
		  },

		  _oSetButtHide: function (tabVal) {
			const oButtonExp = this.byId("exportSelectedButton");
			const oButtonTerAll = this.byId("terminateAllAccessButton");
			const oButtonExpSub = this.byId("submitChangesButton");
			const oBbutExp = tabVal === "endUsers"? oButtonExp.setVisible(false) : oButtonExp.setVisible(true);
			const oButTerm = tabVal === "endUsers"? oButtonTerAll.setVisible(false) : oButtonTerAll.setVisible(true);
			const oButExp = tabVal === "endUsers"? oButtonExpSub.setVisible(false) : oButtonExpSub.setVisible(true);

		  },
		 
		  //New version of the model
		  //As per tabs fetching user list start
		  loadEnerlineUsersAcsRights: async function (sBusinessPartnerID, bpId) {
			const oModel = this.getView().getModel("mainModel");
		  
			try {
			  // Step 1: Get all UserCompanies under Company BP
			  const aUserCompaniesCtx = await oModel
				.bindList("/UserCompanies", null, null, [
				  new sap.ui.model.Filter("CompanyBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, sBusinessPartnerID)
				])
				.requestContexts();
		  
			  const aUserCompanies = aUserCompaniesCtx.map(ctx => ctx.getObject());
		  
			  // Optional: filter to only specific bpId (ContactBP)
			  const aFilteredUserCompanies = bpId
				? aUserCompanies.filter(u => u.ContactBP_ContactBP === bpId)
				: aUserCompanies;
		  
			  const aUserIds = aFilteredUserCompanies.map(u => u.ContactBP_ContactBP);
		  
			  if (aUserIds.length === 0) {
				console.warn("No matching user IDs found.");
				return [];
			  }
		  
			  // Step 2: Get Users
			  const aUserFilters = aUserIds.map(bp =>
				new sap.ui.model.Filter("ContactBP", sap.ui.model.FilterOperator.EQ, bp)
			  );
			  const oUserFilter = new sap.ui.model.Filter({ filters: aUserFilters, and: false });
		  
			  const aUserCtx = await oModel.bindList("/Users", null, null, [oUserFilter]).requestContexts();
			  const aUsers = aUserCtx.map(ctx => ctx.getObject());
		  
			  // Step 3: Get Access Rights
			  const aAccessFilters = aUserIds.map(bp =>
				new sap.ui.model.Filter("BPNumber", sap.ui.model.FilterOperator.EQ, bp)
			  );
			  const oAccessFilter = new sap.ui.model.Filter({ filters: aAccessFilters, and: false });
		  
			  const aAccessCtx = await oModel.bindList("/BPAccessRights", null, null, [oAccessFilter]).requestContexts();
			  const aAccessRights = aAccessCtx.map(ctx => ctx.getObject());
		  
			  // Step 4: Access Right Types and Definitions
			  const aTypeCtx = await oModel.bindList("/AccessRightType").requestContexts();
			  const aTypes = aTypeCtx.map(ctx => ctx.getObject());
		  
			  const aAccessCtx2 = await oModel.bindList("/AccessRights").requestContexts();
			  const aAccessFull = aAccessCtx2.map(ctx => ctx.getObject());
		  
			  // Step 5: Format Final Output
			  const aEnerlineUsers = aUsers.map(user => {
				const userAccess = aAccessRights.filter(r => {
				  const isSameBP = r.BPNumber === user.ContactBP;
				  const isActive = !r.endDate || new Date(r.endDate) >= new Date();
				  return isSameBP && isActive;
				});
		  
				const access = {};
				userAccess.forEach(entry => {
				  const type = aTypes.find(t => t.code === entry.AccessRights_accessRightType_code);
				  const accessEntry = aAccessFull.find(a => a.code === entry.AccessRights_code);
		  
				  if (type && accessEntry) {
					if (!access[type.name]) access[type.name] = [];
					access[type.name].push({
					  title: accessEntry.name,
					  AccessRight_ID: accessEntry.code,
					  id: entry.ID,
					  effectiveDate: entry.startDate,
					  endDate: entry.endDate,
					  selected: true
					});
				  }
				});
		  
				return {
				  name: `${user.firstName} ${user.lastName}`,
				  bpNumber: `${user.ContactBP}`,
				  relationBP: sBusinessPartnerID,
				  access
				};
			  });
		  
			  // Return only the first matched user if bpId was passed
			  if (bpId && aEnerlineUsers.length > 0) {
				return aEnerlineUsers[0]; // return object not array
			  }
		  
			  return aEnerlineUsers;
			} catch (err) {
			  console.error("Failed to load user access data:", err);
			}
		  },

		  loadSingleAgentCompanyAccess: async function (sCompanyBPID, bpId) {
			try {
			  const oModel = this.getView().getModel("mainModel");
		  
			  // 1. Fetch AgentCompany by exact BP ID and relation
			  const aAgentCtx = await oModel.bindList("/AgentCompanies", null, null, [
				new sap.ui.model.Filter("ContractHolderBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, sCompanyBPID),
				new sap.ui.model.Filter("AgentBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, bpId)
			  ]).requestContexts();
			  const agent = aAgentCtx.length ? aAgentCtx[0].getObject() : null;
			  if (!agent) {
				console.warn("No matching AgentCompany found.");
				return null;
			  }
		  
			  // 2. Get matching BPAccessRights (active + correct company + correct agent)
			  const aAccessCtx = await oModel.bindList("/BPAccessRights", null, null, [
				new sap.ui.model.Filter("BPNumber", sap.ui.model.FilterOperator.EQ, bpId),
				new sap.ui.model.Filter("RelationBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, sCompanyBPID)
			  ]).requestContexts();
			  const aAccessRights = aAccessCtx
				.map(ctx => ctx.getObject())
				.filter(entry => !entry.endDate || new Date(entry.endDate) >= new Date());
		  
			  // 3. Load Access Types and Full Access Rights
			  const [aTypes, aRights, aCompanyCtx] = await Promise.all([
				oModel.bindList("/AccessRightType").requestContexts(),
				oModel.bindList("/AccessRights").requestContexts(),
				oModel.bindList("/Companies", null, null, [
				  new sap.ui.model.Filter("BusinessPartnerID", sap.ui.model.FilterOperator.EQ, bpId)
				]).requestContexts()
			  ]);
		  
			  const oTypes = aTypes.map(ctx => ctx.getObject());
			  const oRights = aRights.map(ctx => ctx.getObject());
			  const matchedCompany = aCompanyCtx.length ? aCompanyCtx[0].getObject() : null;
		  
			  // 4. Build Access Object
			  const access = {};
			  aAccessRights.forEach(entry => {
				const type = oTypes.find(t => t.code === entry.AccessRights_accessRightType_code);
				const right = oRights.find(r => r.code === entry.AccessRights_code);
				if (type && right) {
				  if (!access[type.name]) access[type.name] = [];
				  access[type.name].push({
					title: right.name,
					AccessRight_ID: right.code,
					id: entry.ID,
					effectiveDate: entry.startDate,
					endDate: entry.endDate,
					selected: true
				  });
				}
			  });
		  
			  return {
				name: matchedCompany?.Name || "Unknown",
				bpNumber: bpId,
				relationBP: sCompanyBPID,
				access
			  };
		  
			} catch (err) {
			  console.error("❌ Failed to load single agent access record:", err);
			  return null;
			}
		  },

		  loadSingleEndCustomerAccess: async function (sCompanyBPID, bpId) {
			try {
			  const oModel = this.getView().getModel("mainModel");
		  
			  // 1. Fetch AgentCompany with given AgentBP and matching ContractHolder
			  const aAgentCtx = await oModel.bindList("/AgentCompanies", null, null, [
				new sap.ui.model.Filter("AgentBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, sCompanyBPID),
				new sap.ui.model.Filter("ContractHolderBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, bpId)
			  ]).requestContexts();
			  const agent = aAgentCtx.length ? aAgentCtx[0].getObject() : null;
			  if (!agent) {
				console.warn("No matching End Customer AgentCompany found.");
				return null;
			  }
		  
			  // 2. Fetch Access Rights: match both BPNumber and RelationBP
			  const aAccessCtx = await oModel.bindList("/BPAccessRights", null, null, [
				new sap.ui.model.Filter("BPNumber", sap.ui.model.FilterOperator.EQ, bpId),
				new sap.ui.model.Filter("RelationBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, sCompanyBPID)
			  ]).requestContexts();
			  const aAccessRights = aAccessCtx
				.map(ctx => ctx.getObject())
				.filter(entry => !entry.endDate || new Date(entry.endDate) >= new Date());
		  
			  // 3. Fetch type definitions and full access rights
			  const [aTypesCtx, aAccessFullCtx, aCompanyCtx] = await Promise.all([
				oModel.bindList("/AccessRightType").requestContexts(),
				oModel.bindList("/AccessRights").requestContexts(),
				oModel.bindList("/Companies", null, null, [
				  new sap.ui.model.Filter("BusinessPartnerID", sap.ui.model.FilterOperator.EQ, bpId)
				]).requestContexts()
			  ]);
			  const aTypes = aTypesCtx.map(ctx => ctx.getObject());
			  const aAccessFull = aAccessFullCtx.map(ctx => ctx.getObject());
			  const matchedCompany = aCompanyCtx.length ? aCompanyCtx[0].getObject() : null;
		  
			  // 4. Structure access entries
			  const access = {};
			  aAccessRights.forEach(entry => {
				const type = aTypes.find(t => t.code === entry.AccessRights_accessRightType_code);
				const right = aAccessFull.find(r => r.code === entry.AccessRights_code);
		  
				if (type && right) {
				  if (!access[type.name]) access[type.name] = [];
				  access[type.name].push({
					title: right.name,
					AccessRight_ID: right.code,
					id: entry.ID,
					effectiveDate: entry.startDate,
					endDate: entry.endDate,
					selected: true
				  });
				}
			  });
		  
			  return {
				name: matchedCompany?.Name || "Unknown",
				bpNumber: bpId,
				relationBP: sCompanyBPID,
				access
			  };
		  
			} catch (err) {
			  console.error("❌ Failed to load single End Customer access data:", err);
			  return null;
			}
		  },

		//ending fetching users list


		_onSelectUserAccess: async function (oBPInx, oSelcTab) {
			
			const oShellModel = this.getOwnerComponent().getModel("sCompanySelc");
			const sBPID = oShellModel?.getProperty("/selectedCompany");
			const oCompanyId = sBPID? sBPID : "7000000001";

			const oUsersModel = this.getOwnerComponent().getModel("usersList");
			const oBPId = oUsersModel.oData[oSelcTab][oBPInx].bpNumber;
			const oBPRls = oUsersModel.oData[oSelcTab][oBPInx].relationBP;
			console.log("selc Details UserData>>", oUsersModel.oData[oSelcTab][oBPInx].relationBP);
			
			const oListData = await Promise.all([ oSelcTab === "enerlineUsers" 
			? this.loadEnerlineUsersAcsRights(oBPRls, oBPId)
			: oSelcTab === "agentUsers"
			? this.loadSingleAgentCompanyAccess(oBPRls, oBPId)
			: oSelcTab === "endUsers"
			? this.loadSingleEndCustomerAccess(oBPRls, oBPId)
			: null
		]);

		const oFinalModelAccessRights = {
			[oSelcTab] : oListData[0],
			
		  };
		  	console.log("oFinalModelAccessRights>>>", oFinalModelAccessRights);
			console.log(oSelcTab, "Data>>>>", oListData);
			
			const oAccessModel = new sap.ui.model.json.JSONModel(oFinalModelAccessRights);
			oAccessModel.setSizeLimit(1000);
			this.getOwnerComponent().setModel(oAccessModel, "usersRights");

			return oAccessModel;
			
		},
		  //end new version of the model

		  _onProductMatched: async function (oEvent) {
			const that = this;
			const today = new Date().toISOString().split("T")[0];
			const oVBox = this.byId("accessContainer2");
			//const oBusy = new sap.m.BusyDialog({ text: "Loading user access..." });
			//oBusy.open();
			sap.ui.core.BusyIndicator.show(0);
		
			try {
				this.byId("submitChangesButton").setEnabled(false); // Disable button initially
				this._oBPid = oEvent.getParameter("arguments").oBPid || this._oBPid || "0";
				const ouserBPid = this._oBPid;
				this.oTabPath = oEvent.getParameter("arguments").oTabPath;
				const oPath = this.oTabPath ? this.oTabPath : "enerlineUsers";
		
				// Load access data
				const oAccesslistData = await this._onSelectUserAccess(ouserBPid, oPath);
				const accessData = oAccesslistData.oData[oPath].access;
				this._oSetButtHide(this.oTabPath);
		
				// Remove old content before creating new
				oVBox.removeAllItems();
		
				// Get role definitions
				const oUsersModel = this.getOwnerComponent().getModel("cmmAccessRights").getData();
				const rolesNew = oUsersModel.cmmRoles;
		
				(rolesNew || []).forEach(function (sCategory, iIndex) {
					/*const oPanel = new sap.m.Panel({
						expandable: true,
						expanded: iIndex === 0,
						headerText: sCategory.categoryName
					});*/

					/*const oInfoDialog = new sap.m.Dialog({
						title: "Info",
						content: new sap.m.Text({
						  text: "Allows company representative to view or manage access rights."
						}),
						beginButton: new sap.m.Button({
						  text: "Close",
						  press: function () {
							oInfoDialog.close();
						  }
						})
					  });
					  
					  // Create custom header HBox to mimic default header
					  const oHeaderBox = new sap.m.HBox({
						justifyContent: "SpaceBetween",
						alignItems: "Center",
						width: "100%",
						items: [
						  new sap.m.Text({ text: sCategory.categoryName }), // main text
						  new sap.m.Button({
							icon: "sap-icon://hint",
							type: "Transparent",
							press: function () {
							  oInfoDialog.open();
							}
						  })
						]
					  });
					  
					  // Create panel with customHeader (preserves expand/collapse)
					  const oPanel = new sap.m.Panel({
						expandable: true,
						expanded: iIndex === 0,
						headerText: sCategory.categoryName, // still works for a11y
						headerToolbar: new sap.m.Toolbar({
						  content: [oHeaderBox],
						  style: "Clear" // 🔥 Important: Avoids overriding default panel look
						})
					  });*/

					/*const oDialog = new sap.m.Dialog({
						title: "Access Information",
						content: new sap.m.Text({
						  text: "Allows company representative to view or manage access rights."
						}),
						beginButton: new sap.m.Button({
						  text: "Close",
						  press: function () {
							oDialog.close();
						  }
						})
					  });
					  
					  // Create header with category title and an icon button
					  const oHeaderToolbar = new sap.m.Toolbar({
						content: [
						  new sap.m.Title({ text: sCategory.categoryName }),
						  new sap.m.ToolbarSpacer(),
						  new sap.m.Button({
							icon: "sap-icon://hint",
							tooltip: "More Info",
							press: function () {
							  oDialog.open();
							}
						  })
						]
					  });
					  
					  // Create the panel using headerToolbar
					  const oPanel = new sap.m.Panel({
						expandable: true,
						expanded: iIndex === 0,
						headerToolbar: oHeaderToolbar
					  });*/
					
					  
					  const oPopover = new sap.m.Popover({
						content: new sap.m.Text({
						  text: "Allows company representative to view or manage access rights on the company’s behalf."
						}),
						placement: sap.m.PlacementType.Bottom
					  });
					  
					  // Create the icon
					  const oHintIcon = new sap.ui.core.Icon({
						src: "sap-icon://hint",
						size: "1rem",
						color: "#0a6ed1",
						tooltip: "Click for more info",
						press: function (oEvent) {
						  oEvent.cancelBubble(); // Prevent toggling the panel expand
						  oPopover.openBy(oEvent.getSource());
						}
					  }).addStyleClass("sapUiSmallMarginBegin");
					  
					  // Create a simple text + icon header
					  // @ts-ignore
					  const oHeaderHBox = new sap.m.HBox({
						width: "100%",
						alignItems: "Center",
						justifyContent: "SpaceBetween",
						items: [
						  new sap.m.Title({ text: sCategory.categoryName }),
						  oHintIcon
						]
					  }).addStyleClass("sapUiTinyMargin sapUiCursorPointer");
					  
					  // Create the panel
					  const oPanel = new sap.m.Panel({
						expandable: true,
						expanded: iIndex === 0,
						headerToolbar: new sap.m.Toolbar({
						  content: [oHeaderHBox],
						  style: "Clear" // 🔥 This preserves default spacing and padding
						})
					  });
		
					  const oTable = new sap.m.Table({
						columns: [
						  new sap.m.Column({
							header: new sap.m.Text({ text: "Access" }),
							demandPopin: false, // Always visible
							minScreenWidth: "Phone" // Show on all devices
						  }),
						  new sap.m.Column({
							header: new sap.m.Text({ text: "Effective Date" }),
							demandPopin: true, // Will move to popin on small screens
							minScreenWidth: "Tablet"
						  }),
						  new sap.m.Column({
							header: new sap.m.Text({ text: "End Date" }),
							demandPopin: true, // Will move to popin on small screens
							minScreenWidth: "Tablet"
						  })
						]
					  });
					oTable.addStyleClass("oDetailTable");
		
					// Deduplicate access rights by title
					let exitingUserRight = accessData[sCategory.categoryName] || [];
					const uniqueRightMap = {};
					exitingUserRight.forEach(item => {
						if (!uniqueRightMap[item.title]) {
							uniqueRightMap[item.title] = item;
						}
					});
					exitingUserRight = Object.values(uniqueRightMap);
		
					// Create table rows
					(sCategory.accessRights || []).forEach(function (oRight) {
						const datauser = exitingUserRight.find((data) => data.title === oRight.rightName);
						const oBPtblId = datauser ? datauser.id : null;
						const orCeck = !!datauser;
						const oEffectiveDate = datauser ? datauser.effectiveDate : null;
						const oEndDate = datauser ? datauser.endDate : null;
		
						const oRowItem = new sap.m.ColumnListItem();
						let oEffInput, oEndInput;
		
						const oEffDtHide = oEffectiveDate
							? new sap.m.Text({ text: oEffectiveDate })
							: (oEffInput = new sap.m.Input({
								type: "Date",
								placeholder: "Effective Date",
								liveChange: function (oEvent) {
									const oInput = oEvent.getSource();
									const val = oInput.getValue();
									oRowItem.addStyleClass("highlightRow");
									oInput.setValueState("None");
		
									if (val && val < today) {
										oInput.setValueState("Error");
										oInput.setValueStateText("Effective date cannot be in the past");
									}
		
									that._validateAllInputs();
								}
							}));
		
						const oEndDateChk = oEndDate
							? new sap.m.Text({ text: oEndDate })
							: (oEndInput = new sap.m.Input({
								type: "Date",
								placeholder: "End Date",
								liveChange: function (oEvent) {
									const oInput = oEvent.getSource();
									const endVal = oInput.getValue();
									const effVal = oEffInput ? oEffInput.getValue() : null;
									oRowItem.addStyleClass("highlightRow");
									oInput.setValueState("None");
		
									if (endVal && endVal < today) {
										oInput.setValueState("Error");
										oInput.setValueStateText("End Date cannot be in the past");
										return;
									}
		
									if (effVal && endVal && endVal < effVal) {
										oInput.setValueState("Error");
										oInput.setValueStateText("End Date cannot be before Effective Date");
										return;
									}
		
									that._validateAllInputs();
								}
							}));
		
						const oCheckBox = new sap.m.CheckBox({
							text: oRight.rightName,
							selected: orCeck,
							select: function () {
								oRowItem.addStyleClass("highlightRow");
								that._validateAllInputs();
							}
						});
		
						oCheckBox.addCustomData(new sap.ui.core.CustomData({
							key: "id",
							value: oBPtblId
						}));
		
						oRowItem.addCell(oCheckBox);
						oRowItem.addCell(oEffDtHide);
						oRowItem.addCell(oEndDateChk);
						oTable.addItem(oRowItem);
					});
		
					oPanel.addContent(oTable);
					oVBox.addItem(oPanel);
				});
		
				// Bind current selected record for detail binding
				this.getView().bindElement({
					path: "/" + oPath + "/" + this._oBPid,
					model: "cmmAccessRights"
				});
		
			} catch (err) {
				console.error("❌ Error in _onProductMatched:", err);
			} finally {
				//oBusy.close();
				sap.ui.core.BusyIndicator.hide();
			}
		},
			  _validateAllInputs: function () {
				const oView = this.getView();
			  
				// 1. Valid input fields (non-empty + no error)
				const aValidInputs = oView.findElements(true).filter(el =>
				  el instanceof sap.m.Input &&
				  el.getVisible() &&
				  el.getEditable() &&
				  el.getValue().trim() !== "" &&
				  el.getValueState() !== "Error"
				);
			  
				// 2. Selected checkboxes
				const aSelectedCheckboxes = oView.findElements(true).filter(el =>
				  el instanceof sap.m.CheckBox &&
				  el.getVisible() &&
				  el.getSelected()
				);
			  
				// 3. Deselected checkboxes (previously selected)
				let aDeselected = [];
				const oPath = this.oTabPath || "enerlineUsers";
				//const oAccessModel = this.getOwnerComponent().getModel("usersRights");
				const oContext = this.getOwnerComponent().getModel("usersRights").getData(); 
				const accessData = oContext[oPath].access;

				//const oPath = this.oTabPath || "enerlineUsers";
				//const sPath = "/" + oPath + "/" + this._oBPid;
				//const oUserData = oAccessModel.getProperty(sPath);
				const oOldRights = accessData || {};
			  
				const oContainer = this.byId("accessContainer2");
				const aPanels = oContainer.getItems();
			  
				for (const oPanel of aPanels) {
				  const sCategory = oPanel.getHeaderText();
				  const oTable = oPanel.getContent()[0];
				  const aItems = oTable.getItems();
			  
				  for (const oItem of aItems) {
					const [oCheckBox] = oItem.getCells();
					const bSelected = oCheckBox.getSelected();
					const oCheckBPid = oCheckBox.getCustomData().find(cd => cd.getKey() === "id")?.getValue();
					const oOldEntry = oOldRights[sCategory]?.find(a => a.id === oCheckBPid);
			  
					if (!bSelected && oOldEntry) {
					  aDeselected.push(oCheckBox);
					}
				  }
				}
			  
				// 4. Final logic: enable if any valid input OR selection OR deselection
				const bEnableSubmit =
				  aValidInputs.length > 0 ||
				  aSelectedCheckboxes.length > 0 ||
				  aDeselected.length > 0;
			  
				this.byId("submitChangesButton").setEnabled(bEnableSubmit);
			  },
			  
		onDateChangeValidate: function (oEvent) {
			const oDatePicker = oEvent.getSource();
			const sSelectedDate = oDatePicker.getValue();
			const today = new Date();
			today.setHours(0, 0, 0, 0);
		  
			const oDate = new Date(sSelectedDate);
			oDate.setHours(0, 0, 0, 0);
		  
			if (oDate < today) {
			  sap.m.MessageBox.warning("Selected date cannot be before today.");
			  oDatePicker.setValue(""); // Clear invalid value
			}
		  }
			
					
	});
});


