sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/mvc/XMLView",
	"sap/m/ColumnListItem",
	"sap/m/MessageBox",
	"sap/m/ObjectIdentifier",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	//"cmmaccessadminrights/utils/CommonFunctions"

], function (JSONModel, Controller, XMLView, ColumnListItem, MessageBox, ObjectIdentifier, DateFormat, Filter, FilterOperator, CommonFunctions) {
	"use strict";

	return Controller.extend("cmmaccessadminrights.controller.FlexibleColumnLayout", {
		_bEditMode: false,
		onInit: function (oEvent) {
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oRouter.attachRouteMatched(this.onRouteMatched, this);
			this.oRouter.attachBeforeRouteMatched(this.onBeforeRouteMatched, this);
			this.onTaabSelect("tab1");
			this._onMobileView(oEvent);
		  
			//this._getOrCreateFCL("tab1");
			this.onAfterRender();
			console.log("Device Info → Phone:", sap.ui.Device.system.phone);
			
		},

		_onMobileView: function (oEvent) { 
			this.oRouter = this.getOwnerComponent().getRouter(); 
			/*const oFCL = this.byId("fcl");
			const oUIModel = new sap.ui.model.json.JSONModel({
			isPhone: sap.ui.Device.system.phone
			});
			this.getView().setModel(oUIModel, "device");

			if (sap.ui.Device.system.phone) {
				alert('click Check Flex');
			oFCL.setLayout(sap.f.LayoutType.OneColumn);
			} else {
			oFCL.setLayout(sap.f.LayoutType.TwoColumnsMidExpanded);
			}this.getView().getModel("device").setProperty("/isPhone", sap.ui.Device.system.phone);*/
			const oRouter = this.getOwnerComponent().getRouter();
			const bIsPhone = sap.ui.Device.system.phone;
			if (bIsPhone) {
				this.oRouter.getRoute("detail").attachPatternMatched(this._onDetailMatched, this);
				this.oRouter.getRoute("list").attachPatternMatched(this._onListMatched, this);
			} else {
			this.oRouter.navTo("list", { layout: "TwoColumnsMidExpanded", tab: "tab1"});	
			//this.oRouter.navTo("detail", { layout: "TwoColumnsMidExpanded", oBPid: "0", oTabPath: "enerlineUsers" });
			}
			// Navigating to a random oBPid in order to display two columns initially
			//this.oRouter.navTo("list", { layout: "OneColumn" });

			//this.oRouter.navTo("detail", { layout: "TwoColumnsMidExpanded", oBPid: "0", oTabPath "enerlineUsers" });
			
		},
		_onDetailMatched: function (oEvent) {
			const sLayout = oEvent.getParameter("arguments").layout;
			const oFCL = this.byId("fcl");
			oFCL.setLayout(sLayout); // ✅ Apply layout manually from URL
		  },
		  
		  _onListMatched: function (oEvent) {
			
			const sLayout = oEvent.getParameter("arguments").layout;
			const oFCL = this.byId("fcl");
			oFCL.setLayout(sLayout); // ✅ For list route too
		  },

		onBeforeRouteMatched: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel();

			var sLayout = oEvent.getParameters().arguments.layout;

			// If there is no layout parameter, query for the default level 0 layout (normally OneColumn)
			if (!sLayout) {
				var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(0);
				sLayout = oNextUIState.layout;
			}

			// Update the layout of the FlexibleColumnLayout
			if (sLayout) {
				oModel.setProperty("/layout", sLayout);
			}
		},

		onRouteMatched: function (oEvent) {
			var sRouteName = oEvent.getParameter("name"),
				oArguments = oEvent.getParameter("arguments");
			//oAccessData = oEvent.getParameter("accessData");

			this._updateUIElements();

			// Save the current route name
			this.currentRouteName = sRouteName;
			this.currentBPid = oArguments.oBPid;
			this.currentTabpath = oArguments.oTabPath;

		},

		onStateChanged: function (oEvent) {
			//start setting fcl id
			this.oRouter = this.getOwnerComponent().getRouter();
			this.oRouter.attachRouteMatched(this.onRouteMatched, this);


			var bIsNavigationArrow = oEvent.getParameter("isNavigationArrow"),
				sLayout = oEvent.getParameter("layout");

			this._updateUIElements();
			
			// Replace the URL with the new layout if a navigation arrow was used
			if (bIsNavigationArrow) {
				this.oRouter.navTo(this.currentRouteName, { layout: sLayout, oBPid: this.currentBPid, oTabPath: this.currentTabpath }, true);
			}
		},

		// Update the close/fullscreen buttons visibility
		_updateUIElements: function () {

			var oModel = this.getOwnerComponent().getModel();
			var oUIState = this.getOwnerComponent().getHelper().getCurrentUIState();
			oModel.setData(oUIState);
		},

		onExit: function () {
			this.oRouter.detachRouteMatched(this.onRouteMatched, this);
			this.oRouter.detachBeforeRouteMatched(this.onBeforeRouteMatched, this);
		},

		//access rights

		onAfterRender: function () {// Perform any necessary updates after rendering
			const oIconTabBar = this.byId('idTabBar');
			const sSelectedKey = oIconTabBar.getSelectedKey()|| 'tab1';
			//const oTargetPage = this.byId("container22");
			//oTargetPage.visibility(false);
			const oPageER = this.byId("container22");
			if (oPageER) {
				oPageER.addStyleClass("sapUiHidden"); // hides via CSS
			}
			this._handleTabChange(sSelectedKey);
			//this.onTaabSelect(sSelectedKey);
			//this._handleTabChange(sSelectedKey);	
			return sSelectedKey;
		},
		_getOrCreateFCL: function (oTabval) {
			//this._handleTabChange(oTabval);
			let oFCL = this.byId("fcl");
			console.log('find fcl', oFCL);
			const oPage = this.byId("container6");

			//const oFclActive = oFCL.getEnabled();
			//console.log('oFclActive', oFclActive);

			if (!oFCL) {
				oFCL = new sap.f.FlexibleColumnLayout({
					id: this.createId("fcl"),
					layout: "{/layout}",
					backgroundDesign: "Translucent",
					stateChange: this.onStateChanged.bind(this)
				});
				oPage.addContent(oFCL);
			}
			oPage.addContent(oFCL);
			
			return oFCL;
		},

		_oDynamicListinfo: function (sSelectedKey) {// Perform any necessary updates after rendering
			console.log('list V', sSelectedKey);
			let sBindingPath;
			switch (sSelectedKey) {
				case "tab2":
					sBindingPath = "agentUsers";
					break;
				case "tab3":
					sBindingPath = "endUsers";
					
					break;
				case "tab4":
					sBindingPath = "enerlineUsers";
					break;
				case "tab1":
					console.log("1st tab");
					sBindingPath = "enerlineUsers";
					break;
			}

			return sBindingPath;
		},
		onTermSearch: function (oEvent) {
			const sQuery = oEvent.getParameter("query");
			const oTable = this.byId("otermTable"); // make sure ID matches table ID
		 
			const aFilters = [];
		 
			if (sQuery && sQuery.length > 0) {
				// Search both name and access type
				aFilters.push(new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("oEnerlineUsersAgents", sap.ui.model.FilterOperator.Contains, sQuery),
						new sap.ui.model.Filter("oAccessType", sap.ui.model.FilterOperator.Contains, sQuery)
					],
					and: false
				}));
			}
		 
			const oBinding = oTable.getBinding("items");
			if (oBinding) {
				oBinding.filter(aFilters);
			}
		},


		onEditTerminate: function () {
			this._bEditMode = true;

			console.log('this._bEditMode', this._bEditMode);
		 
			const oTable = this.byId("otermTable");
			const aItems = oTable.getItems();
		 
			aItems.forEach(function (oItem) {
				const oCheckBox = oItem.getCells()[0];
				const oHBox = oItem.getCells()[4];
				const aControls = oHBox.getItems();
		 
				if (oCheckBox.getSelected()) {
					aControls[0].setVisible(false); // Text
					aControls[1].setVisible(true);  // DatePicker
				}
			});
		 
			this.byId("oEditTermId").setEnabled(false);
			
		},
		// Binding Left list model
		//As per tabs fetching user list start
			loadEnerlineUsersList: async function (sBusinessPartnerID) {
				const oModel = this.getView().getModel("mainModel");
			
				try {
				// Step 1: Get UserCompanies by CompanyBP_BusinessPartnerID
				const aUserCompaniesCtx = await oModel
					.bindList("/UserCompanies", null, null, [
					new sap.ui.model.Filter(
						"CompanyBP_BusinessPartnerID",
						sap.ui.model.FilterOperator.EQ,
						sBusinessPartnerID
					)
					])
					.requestContexts();
			
				const aUserCompanies = aUserCompaniesCtx.map((ctx) => ctx.getObject());
				const aUserIds = aUserCompanies.map((u) => u.ContactBP_ContactBP);
			
				// Step 2: Get Users matching the ContactBP list
				const aUserFilters = aUserIds.map((bpId) =>
					new sap.ui.model.Filter("ContactBP", sap.ui.model.FilterOperator.EQ, bpId)
				);
				const oUserFilter = new sap.ui.model.Filter({ filters: aUserFilters, and: false });
			
				const aUserCtx = await oModel.bindList("/Users", null, null, [oUserFilter]).requestContexts();
				const aUsers = aUserCtx.map((ctx) => ctx.getObject());
			
				// Step 3: Get Access Rights from BPAccessRights by BPNumber
				const aAccessFilters = aUserIds.map((bpId) =>
					new sap.ui.model.Filter("BPNumber", sap.ui.model.FilterOperator.EQ, bpId)
				);
				const oAccessFilter = new sap.ui.model.Filter({ filters: aAccessFilters, and: false });
			
				const aAccessCtx = await oModel.bindList("/BPAccessRights", null, null, [oAccessFilter]).requestContexts();
				const aAccessRights = aAccessCtx.map((ctx) => ctx.getObject());
			
				// Step 4: Get Access Right Types and Descriptions
				const aTypeCtx = await oModel.bindList("/AccessRightType").requestContexts();
				const aTypes = aTypeCtx.map((ctx) => ctx.getObject());
			
				const aAccessCtx2 = await oModel.bindList("/AccessRights").requestContexts();
				const aAccessFull = aAccessCtx2.map((ctx) => ctx.getObject());
			
				// Step 5: Format Output
				const aEnerlineUsers = aUsers.map((user) => {
					//const userAccess = aAccessRights.filter((r) => r.BPNumber === user.ContactBP);

					const userAccess = aAccessRights.filter((r) => {
						const isSameBP = r.BPNumber === user.ContactBP;
					
						// Keep if no endDate OR if endDate is today or in the future
						const isActive = !r.endDate || new Date(r.endDate) >= new Date();
					
						return isSameBP && isActive;
					});
			
					const access = {};
					userAccess.forEach((entry) => {
					const type = aTypes.find((t) => t.code === entry.AccessRights_accessRightType_code);
					const accessEntry = aAccessFull.find((a) => a.code === entry.AccessRights_code);
			
					if (type && accessEntry) {
						if (!access[type.name]) access[type.name] = [];
						access[type.name].push({
						title: accessEntry.name,
						AccessRight_ID: accessEntry.code,
						id:entry.ID,
						effectiveDate: entry.startDate,
						endDate: entry.endDate,
						selected: true
						});
					}
					});
			
					return {
					name: `${user.firstName} ${user.lastName}`,
					bpNumber: `${user.ContactBP}`,
					relationBP: sBusinessPartnerID,
					access
					};
				});
				console.log('aEnerlineUsers>>>>>', aEnerlineUsers);
				/*const oOutputModel = new sap.ui.model.json.JSONModel({ enerlineUsers: aEnerlineUsers });
				this.setModel(oOutputModel, "userAccessModel");*/
				return aEnerlineUsers;
				} catch (err) {
				console.error("Failed to load user access data:", err);
				}
			},

			loadAgentCompanyList: async function (sCompanyBPID) {
				try {
				const oModel = this.getView().getModel("mainModel");
			
				// 1. Get all Companies
				const aCompanyCtx = await oModel.bindList("/Companies").requestContexts();
				const aCompanies = aCompanyCtx.map(ctx => ctx.getObject());
			
				// 2. Get AgentCompanies for the given Company BP
				const oAgentFilter = new sap.ui.model.Filter("ContractHolderBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, sCompanyBPID);
				const aAgentCtx = await oModel.bindList("/AgentCompanies", null, null, [oAgentFilter]).requestContexts();
				const aAgents = aAgentCtx.map(ctx => ctx.getObject());
				const aAgentBPIds = aAgents.map(a => a.AgentBP_BusinessPartnerID?.trim()).filter(Boolean);
				// 3. Get all BPAccessRights
				const aAllAccessCtx = await oModel.bindList("/BPAccessRights").requestContexts();
				const aAllAccessRights = aAllAccessCtx.map(ctx => ctx.getObject());
			
				// 4. Filter BPAccessRights: BPNumber == AgentBP_BusinessPartnerID AND RelationBP_BusinessPartnerID == sCompanyBPID
				const aFilteredAccessRights = aAllAccessRights.filter(entry =>
					aAgentBPIds.includes(entry.BPNumber?.trim()) &&
					entry.RelationBP_BusinessPartnerID?.trim() === sCompanyBPID.trim()
				);
				
				// 5. Get AccessRightType and AccessRights
				const aTypeCtx = await oModel.bindList("/AccessRightType").requestContexts();
				const aTypes = aTypeCtx.map(ctx => ctx.getObject());
			
				const aAccessFullCtx = await oModel.bindList("/AccessRights").requestContexts();
				const aAccessFull = aAccessFullCtx.map(ctx => ctx.getObject());
			
				// 6. Merge Data
				const aAgentAccessData = aAgents.map(agent => {
					//const agentAccessRights = aFilteredAccessRights.filter(r => r.BPNumber === agent.AgentBP_BusinessPartnerID);

					const agentAccessRights = aFilteredAccessRights.filter((r) => {
						const isSameBP = r.BPNumber === agent.AgentBP_BusinessPartnerID;
					
						// Keep if no endDate OR if endDate is today or in the future
						const isActive = !r.endDate || new Date(r.endDate) >= new Date();
					
						return isSameBP && isActive;
					});
					
					const access = {};
					agentAccessRights.forEach(entry => {
					const type = aTypes.find(t => t.code === entry.AccessRights_accessRightType_code);
					const right = aAccessFull.find(r => r.code === entry.AccessRights_code);
			
					if (type && right) {
						if (!access[type.name]) access[type.name] = [];
			
						access[type.name].push({
						title: right.name,
						AccessRight_ID: right.code,
						id:entry.ID,
						effectiveDate: entry.startDate,
						endDate: entry.endDate,
						selected: true
						});
					}
					});
			
					const matchedCompany = aCompanies.find(c => c.BusinessPartnerID === agent.AgentBP_BusinessPartnerID);
			
					return {
					name: matchedCompany?.Name || "Unknown",
					bpNumber: agent.AgentBP_BusinessPartnerID,
					relationBP: sCompanyBPID,
					access
					};
				});
			
				return aAgentAccessData;
			
				} catch (err) {
				console.error("❌ Failed to load company access data:", err);
				return [];
				}
			},

			loadEndCustomersList: async function (sCompanyBPID) {
				try {
				const oModel = this.getView().getModel("mainModel");
			
				// 1. Get all Companies
				const aCompanyCtx = await oModel.bindList("/Companies").requestContexts();
				const aCompanies = aCompanyCtx.map(ctx => ctx.getObject());
			
				// 2. Get AgentCompanies for the given Company BP
				const oAgentFilter = new sap.ui.model.Filter("AgentBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, sCompanyBPID);
				const aAgentCtx = await oModel.bindList("/AgentCompanies", null, null, [oAgentFilter]).requestContexts();
				const aAgents = aAgentCtx.map(ctx => ctx.getObject());
				const aAgentBPIds = aAgents.map(a => a.ContractHolderBP_BusinessPartnerID?.trim()).filter(Boolean);
			
				// 3. Get all BPAccessRights
				const aAllAccessCtx = await oModel.bindList("/BPAccessRights").requestContexts();
				const aAllAccessRights = aAllAccessCtx.map(ctx => ctx.getObject());
			
				// 4. Filter BPAccessRights: BPNumber == AgentBP_BusinessPartnerID AND RelationBP_BusinessPartnerID == sCompanyBPID
				const aFilteredAccessRights = aAllAccessRights.filter(entry =>
					aAgentBPIds.includes(entry.BPNumber?.trim()) &&
					entry.RelationBP_BusinessPartnerID?.trim() === sCompanyBPID.trim()
				);
				
				// 5. Get AccessRightType and AccessRights
				const aTypeCtx = await oModel.bindList("/AccessRightType").requestContexts();
				const aTypes = aTypeCtx.map(ctx => ctx.getObject());
			
				const aAccessFullCtx = await oModel.bindList("/AccessRights").requestContexts();
				const aAccessFull = aAccessFullCtx.map(ctx => ctx.getObject());
			
				// 6. Merge Data
				const aAgentAccessData = aAgents.map(agent => {
					//const agentAccessRights = aFilteredAccessRights.filter(r => r.BPNumber === agent.ContractHolderBP_BusinessPartnerID);
					
					const agentAccessRights = aFilteredAccessRights.filter((r) => {
						const isSameBP = r.BPNumber === agent.ContractHolderBP_BusinessPartnerID;
					
						// Keep if no endDate OR if endDate is today or in the future
						const isActive = !r.endDate || new Date(r.endDate) >= new Date();
					
						return isSameBP && isActive;
					});

					const access = {};
					agentAccessRights.forEach(entry => {
					const type = aTypes.find(t => t.code === entry.AccessRights_accessRightType_code);
					const right = aAccessFull.find(r => r.code === entry.AccessRights_code);
			
					if (type && right) {
						if (!access[type.name]) access[type.name] = [];
			
						access[type.name].push({
						title: right.name,
						AccessRight_ID: right.code,
						id:entry.ID,
						effectiveDate: entry.startDate,
						endDate: entry.endDate,
						selected: true
						});
					}
					});
			
					const matchedCompany = aCompanies.find(c => c.BusinessPartnerID === agent.ContractHolderBP_BusinessPartnerID);
			
					return {
					name: matchedCompany?.Name || "Unknown",
					bpNumber: agent.ContractHolderBP_BusinessPartnerID,
					relationBP: sCompanyBPID,
					access
					};
				});
			
				return aAgentAccessData;
			
				} catch (err) {
				console.error("Failed to load company CtractHolder access data:", err);
				return [];
				}
			},

			//ending fetching users list


			_onSelectUserTab: async function (oSelcTab) {
				
				const oShellModel = this.getOwnerComponent().getModel("sCompanySelc");
				const sBPID = oShellModel?.getProperty("/selectedCompany");
				const oCompanyId = sBPID? sBPID : "7000000001"
				console.log("selc Company>>", oCompanyId);
				
				const oListData = await Promise.all([ oSelcTab === "enerlineUsers" 
				? this.loadEnerlineUsersList(oCompanyId)
				: oSelcTab === "agentUsers"
				? this.loadAgentCompanyList(oCompanyId)
				: oSelcTab === "endUsers"
				? this.loadEndCustomersList(oCompanyId)
				: null
			]);

			const oFinalModelAccessRights = {
				[oSelcTab] : oListData[0],
				
			};
				console.log("oFinalModelAccessRights flex >>>", oFinalModelAccessRights);
				console.log(oSelcTab, "flex Data>>>>", oListData);
				const oAccessModel = new sap.ui.model.json.JSONModel(oFinalModelAccessRights);
				oAccessModel.setSizeLimit(1000);
				this.getOwnerComponent().setModel(oAccessModel, "usersList");

				return oAccessModel;
				
			},



		//end left list model

		_bindDynamicTable: async function (sSelectedTabKey) {
			const cTabKey = this._oDynamicListinfo(sSelectedTabKey);
			const sPath = "/" + cTabKey;
			const oFCLt = this.byId("fcl");
			const obeginPage = oFCLt.getCurrentBeginColumnPage();
			const oTable = obeginPage.byId("productsTable");
		
			// Clear existing model data
			const oModel = this.getOwnerComponent().getModel("usersList");
			if (oModel) {
				oModel.setProperty(sPath, []); // Reset the old tab data
			}
		
			// Show loading indicator
			oTable.setBusy(true);
		
			// Load and set new model data
			await this._onSelectUserTab(cTabKey); // async model fetch sets "usersList"
		
			oTable.unbindItems(); // Clear old binding
			oTable.bindItems({
				path: "usersList>/" + cTabKey,
				template: new sap.m.ColumnListItem({
					type: "Navigation",
					cells: [
						new sap.m.ObjectIdentifier({
							title: "{usersList>name}",
							text: "{usersList>name}"
						})
					]
				})
			});
		
			oTable.setBusy(false); // Stop loading
		
			// Auto select first and navigate
			oTable.attachUpdateFinished(() => {
				const aItems = oTable.getItems();
				if (aItems.length > 0) {
					oTable.setSelectedItem(aItems[0]);
				}
		
				const bIsPhone = sap.ui.Device.system.phone;
				if (!bIsPhone) {
					this.getOwnerComponent().getRouter().navTo("detail", {
						layout: "TwoColumnsMidExpanded",
						oBPid: 0,
						oTabPath: cTabKey
					});
				}
			});
		},
		//Submit Change future termination
		_onSubmitChangesFurTermPress: async function () {
			const that = this;
			const oMainModel = that.getView().getModel("mainModel");
			const oAccessModel = that.getOwnerComponent().getModel("terminationModel");
			const oTable = this.byId("otermTable");
		  
			const aItems = oTable.getItems();
			let bAtLeastOneSelected = false;
		  
			for (let oItem of aItems) {
			  const oCheckBox = oItem.getCells()[0];
		  
			  if (!oCheckBox.getSelected()) {
				continue; // Skip unchecked rows
			  }
		  
			  bAtLeastOneSelected = true;
			  let bRowChanged = false;
		  
			  try {
				const oCustomData = oCheckBox.getCustomData();
				const oTFId = oCustomData.find(d => d.getKey() === "id")?.getValue();
		  
				const sPath = `/${aItems.indexOf(oItem)}`;
				const oUserData = oAccessModel.getProperty(sPath);
				const sBPId = oUserData.BPId;
				const sRelationBP = oUserData.RelationBP;
				const sAccessType = oItem.getCells()[2].getText(); // 'I' or 'A'
				const sTerminationType = oItem.getCells()[3].getText(); // 'TEA' or 'TER'
				const oHBox = oItem.getCells()[4];
				console.log("old Date check",oUserData );
				let sTerminationDate = "";
				if (oHBox instanceof sap.m.HBox) {
				  const oDatePicker = oHBox.getItems()[1];
				  sTerminationDate = oDatePicker.getValue();
				}
				const sOriginalDate = oUserData.oTerminationDate;
				console.log(sOriginalDate, "before edit enable", sTerminationDate);
				/*if (sOriginalDate === sTerminationDate) {
				sap.m.MessageBox.warning("Termination date has not been changed. Please click edit button to update the new change date to proceed.");
				return;
				}*/
		  
				// Step 1: Update BPAccessRights
				
				const oFilter1 = new sap.ui.model.Filter("BPNumber", sap.ui.model.FilterOperator.EQ, sBPId);
				const oFilter2 = new sap.ui.model.Filter("RelationBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, sRelationBP);
				// Combine filters with AND
				const userFilter = new sap.ui.model.Filter([oFilter1, oFilter2], true); // `true` = AND
				// Bind list with filter
				const oBindAGVal = oMainModel.bindList("/BPAccessRights", undefined, undefined, userFilter);
				const aContexts = await oBindAGVal.requestContexts();
				const aRights = aContexts.map(ctx => ctx.getObject());
				console.log("Read AgentCompanies:", aRights);

				for (const r of aRights) {
				  const sUpdatePath = `/BPAccessRights(ID='${r.ID}')`;
				  const oContext = oMainModel.bindContext(sUpdatePath, null, { $$groupId: "submitGroup" });
				  const oContextBP = await oContext.getBoundContext();
				  oContextBP.setProperty("endDate", sTerminationDate);
				  //oContextBP.getBinding().setUpdateGroupId("submitGroup");
				  bRowChanged = true;
				}
		  
				// Step 2: Update BPAccessTermination
				const sUpdatePath = `/BPAccessTermination(ID='${oTFId}')`; // Use key-based URL format
				
				const oContextBinding = oMainModel.bindContext(sUpdatePath, null, {
					$$groupId: "submitGroup"
				});
				const oBoundContext = oContextBinding.getBoundContext();
				oBoundContext.setProperty("Date", sTerminationDate);

				bRowChanged = true;
		  
				// Step 3: Update ValidTo in related entity
				console.log('sTerminationType', sTerminationType);
				if (sTerminationType === "Terminate Enerline Access") {
				 // let sFilterPath = "";
				  if (sAccessType === "I") {
					await that.getUserCompanyDt(sBPId, sRelationBP, sTerminationDate)
					//sFilterPath = `/UserCompanies(CompanyBP_BusinessPartnerID='${sRelationBP}',ContactBP_ContactBP='${sBPId}')`;
				  } else if (sAccessType === "A") {
					await that.getAgentCompanyDt(oUserData?.bpNumber, oUserData?.relationBP, sTerminationDate)
					//sFilterPath = `/AgentCompanies(ContractHolderBP_BusinessPartnerID='${sRelationBP}',AgentBP_BusinessPartnerID='${sBPId}')`;
				  }
		  
				  /*if (sFilterPath) {
					const oEntityCtx = oMainModel.bindContext(sFilterPath, null, { $$groupId: "submitGroup" });
					const oEntityCtxUsr = await oEntityCtx.getBoundContext();
					oEntityCtxUsr.setProperty("ValidTo", sTerminationDate);
					//oEntityCtx.getBinding().setUpdateGroupId("submitGroup");
					bRowChanged = true;
				  }*/
				}
		  
				// ✅ Highlight modified rows
				if (bRowChanged) {
				  oItem.addStyleClass("highlight-piper");
				}
		  
			  } catch (err) {
				console.error("❌ Error in processing row:", err);
				sap.m.MessageBox.error("Error processing one or more termination rows. Check console for details.");
			  }
			}
		  
			// No checkbox was selected
			if (!bAtLeastOneSelected) {
			  sap.m.MessageBox.warning("Please select at least one record to terminate.");
			  return;
			}
		  
			// 🔁 Submit all changes
			try {
			  await oMainModel.submitBatch("submitGroup");
			  await oMainModel.refresh();
			  const oAccessModel = this.getOwnerComponent().getModel("terminationModel");
  			  oAccessModel.refresh(true);
			  sap.m.MessageBox.success("Termination records updated successfully.");
				//this._bindDynamicTerminationTable();
				const oTbloModel = oTable.getModel();
				oTbloModel.refresh(true);
				//oTable.removeAllItems();
				oTable.getBinding("items").refresh();
			 /* const oBinding = oTable.getBinding("items");
				if (oBinding) {
				oBinding.refresh();
				sap.m.MessageToast.show("Table refreshed.");
				}*/
		  
			} catch (err) {
			  console.error("Batch submit failed:", err);
			  sap.m.MessageBox.error("Failed to update termination records.");
			}
		  },
		  getAgentCompanyDt: async function (bpNumber, relationBP, sDate) {
			const that = this;
			//const oModel = that.getModel("mainModel"); // or your relevant model
			const oModel = that.getView().getModel("mainModel");
			const oFilter1 = new sap.ui.model.Filter("AgentBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, bpNumber);
			const oFilter2 = new sap.ui.model.Filter("ContractHolderBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, relationBP);
			// Combine filters with AND
			const userFilter = new sap.ui.model.Filter([oFilter1, oFilter2], true); // `true` = AND
			// Bind list with filter
			const oBindAGVal = oModel.bindList("/AgentCompanies", undefined, undefined, userFilter);
			try {
			const aContexts = await oBindAGVal.requestContexts();
			const aResults = aContexts.map(ctx => ctx.getObject());
			console.log("Read AgentCompanies:", aResults[0].ValidFrom);
			const sUpdatePathC = `/AgentCompanies(AgentBP_BusinessPartnerID='${bpNumber}',ContractHolderBP_BusinessPartnerID='${relationBP}',ValidFrom=${aResults[0].ValidFrom})`;
			const oContextBindingC = oModel.bindContext(sUpdatePathC, null, {
			$$groupId: "submitGroup"
			});
			const oBoundContextC = oContextBindingC.getBoundContext();
			
			if (oBoundContextC) {
			oBoundContextC.setProperty("ValidTo", sDate);
			}
			await oModel.submitBatch("submitGroup");
			return aResults;
			
			} catch (err) {
			console.error("Error reading AgentCompanies:", err);
			}
		  },
		  getUserCompanyDt: async function (bpNumber, relationBP, sDate) {
			const that = this;
			//const oModel = that.getModel("mainModel"); // or your relevant model
			const oModel = that.getView().getModel("mainModel");
			const oFilter1 = new sap.ui.model.Filter("ContactBP_ContactBP", sap.ui.model.FilterOperator.EQ, bpNumber);
			const oFilter2 = new sap.ui.model.Filter("CompanyBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, relationBP);
			// Combine filters with AND
			const userFilter = new sap.ui.model.Filter([oFilter1, oFilter2], true); // `true` = AND
			// Bind list with filter
			const oBindAGVal = oModel.bindList("/UserCompanies", undefined, undefined, userFilter);
			try {
			const aContexts = await oBindAGVal.requestContexts();
			const aResults = aContexts.map(ctx => ctx.getObject());
			console.log("Read UserCompanies:", aResults[0].ValidFrom);
			const sUpdatePathA = `/UserCompanies(ContactBP_ContactBP='${bpNumber}',CompanyBP_BusinessPartnerID='${relationBP}',ValidFrom=${aResults[0].ValidFrom})`;
			const oContextBindingA = oModel.bindContext(sUpdatePathA, null, {
			$$groupId: "submitGroup"
			});
			const oBoundContextA = oContextBindingA.getBoundContext();
			if (oBoundContextA) {
			oBoundContextA.setProperty("ValidTo", sDate);
			}
			await oModel.submitBatch("submitGroup");
			return aResults;
			} catch (err) {
			console.error("Error reading AgentCompanies:", err);
			}
		  },

		// Cancel Future Termination Dynamic 
		_onTerminateFurAllAccessPress: async function () {
			const that = this;
			const oMainModel = that.getView().getModel("mainModel");
			const oAccessModel = that.getOwnerComponent().getModel("terminationModel");
			const oTable = this.byId("otermTable");
		  
			const aItems = oTable.getItems();
			let bAtLeastOneSelected = false;
		  
			for (let oItem of aItems) {
			  const oCheckBox = oItem.getCells()[0];
		  
			  if (!oCheckBox.getSelected()) {
				continue; // Skip unchecked rows
			  }
		  
			  bAtLeastOneSelected = true;
			  let bRowChanged = false;
		  
			  try {
				const oCustomData = oCheckBox.getCustomData();
				const oTFId = oCustomData.find(d => d.getKey() === "id")?.getValue();
		  
				const sPath = `/${aItems.indexOf(oItem)}`;
				const oUserData = oAccessModel.getProperty(sPath);
				const sBPId = oUserData.BPId;
				const sRelationBP = oUserData.RelationBP;
				const sAccessType = oItem.getCells()[2].getText(); // 'I' or 'A'
				const sTerminationType = oItem.getCells()[3].getText(); // 'TEA' or 'TER'
				const oHBox = oItem.getCells()[4];
		  
				let sTerminationDate = null;
				/*if (oHBox instanceof sap.m.HBox) {
				  const oDatePicker = oHBox.getItems()[1];
				  sTerminationDate = oDatePicker.getValue();
				}*/
		  
				// Step 1: Update BPAccessRights
				
				const oFilter1 = new sap.ui.model.Filter("BPNumber", sap.ui.model.FilterOperator.EQ, sBPId);
				const oFilter2 = new sap.ui.model.Filter("RelationBP_BusinessPartnerID", sap.ui.model.FilterOperator.EQ, sRelationBP);
				// Combine filters with AND
				const userFilter = new sap.ui.model.Filter([oFilter1, oFilter2], true); // `true` = AND
				// Bind list with filter
				const oBindAGVal = oMainModel.bindList("/BPAccessRights", undefined, undefined, userFilter);
				const aContexts = await oBindAGVal.requestContexts();
				const aRights = aContexts.map(ctx => ctx.getObject());
				console.log("Read AgentCompanies:", aRights);

				for (const r of aRights) {
				  const sUpdatePath = `/BPAccessRights(ID='${r.ID}')`;
				  const oContext = oMainModel.bindContext(sUpdatePath, null, { $$groupId: "submitGroup" });
				  const oContextBP = await oContext.getBoundContext();
				  oContextBP.setProperty("endDate", sTerminationDate);
				  //oContextBP.getBinding().setUpdateGroupId("submitGroup");
				  bRowChanged = true;
				}
		  
				// Step 2: Update BPAccessTermination
				const sUpdatePath = `/BPAccessTermination(ID='${oTFId}')`; // Use key-based URL format
				
				const oContextBinding = oMainModel.bindContext(sUpdatePath, null, {
					$$groupId: "submitGroup"
				});
				const oBoundContext = oContextBinding.getBoundContext();
				oBoundContext.setProperty("Date", sTerminationDate);
				oBoundContext.setProperty("Status", "Deactive");

				bRowChanged = true;
		  
				// Step 3: Update ValidTo in related entity
				console.log('sTerminationType', sTerminationType);
				if (sTerminationType === "Terminate Enerline Access") {
				 // let sFilterPath = "";
				  if (sAccessType === "I") {
					await that.getUserCompanyDt(sBPId, sRelationBP, sTerminationDate)
					//sFilterPath = `/UserCompanies(CompanyBP_BusinessPartnerID='${sRelationBP}',ContactBP_ContactBP='${sBPId}')`;
				  } else if (sAccessType === "A") {
					await that.getAgentCompanyDt(oUserData?.bpNumber, oUserData?.relationBP, sTerminationDate)
					//sFilterPath = `/AgentCompanies(ContractHolderBP_BusinessPartnerID='${sRelationBP}',AgentBP_BusinessPartnerID='${sBPId}')`;
				  }
		  
				  /*if (sFilterPath) {
					const oEntityCtx = oMainModel.bindContext(sFilterPath, null, { $$groupId: "submitGroup" });
					const oEntityCtxUsr = await oEntityCtx.getBoundContext();
					oEntityCtxUsr.setProperty("ValidTo", sTerminationDate);
					//oEntityCtx.getBinding().setUpdateGroupId("submitGroup");
					bRowChanged = true;
				  }*/
				}
		  
				// ✅ Highlight modified rows
				if (bRowChanged) {
				  oItem.addStyleClass("highlight-piper");
				}
		  
			  } catch (err) {
				console.error("Error in processing row:", err);
				sap.m.MessageBox.error("Error processing one or more termination rows. Check console for details.");
			  }
			}
		  
			// No checkbox was selected
			if (!bAtLeastOneSelected) {
			  sap.m.MessageBox.warning("Please select at least one record to terminate.");
			  return;
			}
		  
			// 🔁 Submit all changes
			try {
			  await oMainModel.submitBatch("submitGroup");
			  
			  await oMainModel.refresh();
			  const oAccessModel = this.getOwnerComponent().getModel("terminationModel");
  			  oAccessModel.refresh(true);
			  sap.m.MessageBox.success("Termination records updated successfully.");
				this._bindDynamicTerminationTable();

			 // sap.m.MessageBox.success("Termination records updated successfully.");
		  
			 /* const oBinding = oTable.getBinding("items");
				if (oBinding) {
				oBinding.refresh();
				sap.m.MessageToast.show("Table refreshed.");
				}*/
		  
			} catch (err) {
			  console.error("❌ Batch submit failed:", err);
			  sap.m.MessageBox.error("Failed to update termination records.");
			}
		},
		
		onCancelTerminationPress: function () {
			const oTable = this.byId("otermTable");
			const aItems = oTable.getItems();
			const oSelectedItem = aItems.find(row => row.getCells()[0].getSelected());
		  
			if (!oSelectedItem) {
			  sap.m.MessageBox.warning("Please select a record to cancel termination.");
			  return;
			}
		  
			const sName = oSelectedItem.getCells()[1].getText(); // assuming 2nd column has name
			sap.m.MessageBox.confirm(
			  `Do you wish to cancel the termination for ${sName}?`,
			  {
				title: "Cancel Termination",
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CLOSE],
				onClose: function (oAction) {
				  if (oAction === sap.m.MessageBox.Action.OK) {
					// 🔁 Trigger your cancelTermination logic here
					this._onTerminateFurAllAccessPress(oSelectedItem); // assume this method does the update
				  }
				}.bind(this)
			  }
			);
		  },
		 
		  onSubmitTerminationChangesPress: function () {
			const oTable = this.byId("otermTable");
			const aItems = oTable.getItems();
			const oSelectedItem = aItems.find(row => row.getCells()[0].getSelected());
		  
			if (!oSelectedItem) {
			  sap.m.MessageBox.warning("Please select a record to submit changes.");
			  return;
			}
		  
			const oHBox = oSelectedItem.getCells()[4]; // Termination Date field (HBox)
			const oDatePicker = oHBox.getItems()[1];
			const sDate = oDatePicker.getValue();
		  
			if (!sDate) {
			  sap.m.MessageBox.warning("Please select a termination date before submitting.");
			  return;
			}
		  
			const sName = oSelectedItem.getCells()[1].getText();
			sap.m.MessageBox.confirm(
			  `Do you wish to change the termination date for ${sName}?`,
			  {
				title: "Submit Changes",
				actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CLOSE],
				onClose: function (oAction) {
				  if (oAction === sap.m.MessageBox.Action.OK) {
					this._onSubmitChangesFurTermPress(oSelectedItem, sDate); // implement your update logic
				  }
				}.bind(this)
			  }
			);
		  },
		  
		  onTerminationCheckboxSelect: function (oEvent) {
			const that = this; 
			
			const bSelected = oEvent.getParameter("selected");
			const oCheckBox = oEvent.getSource();
			const oHBox = oCheckBox.getParent().getCells()[4];
			const aItems = oHBox.getItems();
			const bEditModeId = that.byId("oEditTermId");
			
			const bEditMode = that._bEditMode;
			if (bSelected && bEditMode === false && bEditModeId.getEnabled() === true) {
				aItems[0].setVisible(true); // Text
				aItems[1].setVisible(false);  // DatePicker
				//bEditModeId.setEnabled(false);
			} else if (bSelected && bEditMode === true && bEditModeId.getEnabled() === false) {
				aItems[0].setVisible(false); // Text
				aItems[1].setVisible(true);  // DatePicker
				//bEditModeId.setEnabled(true);
			} else if (bSelected && bEditModeId.getEnabled() === false && bEditMode === false) {
				aItems[0].setVisible(true); // Text
				aItems[1].setVisible(false);  // DatePicker
				bEditModeId.setEnabled(true);	
			} else {
			//	oEditButton.setEnabled(true);
				aItems[0].setVisible(true);  // Text
				aItems[1].setVisible(false); // DatePicker
			}
			//const oCheckBox = oEvent.getSource();
			const oRow = oCheckBox.getParent();
		  
			if (oCheckBox.getSelected()) {
			  oRow.addStyleClass("highlight-piper");
			} else {
			  oRow.removeStyleClass("highlight-piper");
			}
		  },
		  //setting Futured-data termination model
		  fetchUpcomingTerminations: async function (sCompany) {
			//const oModel = this.getModel("mainModel");
			const oModel = this.getView().getModel("mainModel");
			
		  
			try {
			  // Load BPAccessTermination, Users, AgentCompany, Company
			  const [aTermCtx, aUserCtx, aAgentCtx, aCompanyCtx] = await Promise.all([
				oModel.bindList("/BPAccessTermination").requestContexts(),
				oModel.bindList("/Users").requestContexts(),
				oModel.bindList("/AgentCompanies").requestContexts(),
				oModel.bindList("/Companies").requestContexts()
			  ]);
		  
			  const aTermData = aTermCtx.map(ctx => ctx.getObject());
			  const aUserData = aUserCtx.map(ctx => ctx.getObject());
			  const aAgentData = aAgentCtx.map(ctx => ctx.getObject());
			  const aCompanyData = aCompanyCtx.map(ctx => ctx.getObject());
		  
			  const today = new Date().toISOString().split("T")[0];
			  //let idCounter = 1;
		  
			  const result = aTermData
				.filter(item =>
				  item.RelationBP === sCompany &&
				  item.Date >= today &&
				  item.Status >= "Active"
				)
				.map(item => {
				  let fullName = "";
				  let accessType = item.AccessType === "I" ? "Individual User" : "Agent Company";
				  let terminationLabel = item.TerminationType === "TER"
					? "Terminate Enerline Access and Terminate Relationship"
					: "Terminate Enerline Access";
		  
				  if (item.AccessType === "I") {
					const user = aUserData.find(u => u.ContactBP === item.BPId);
					fullName = user ? `${user.firstName} ${user.lastName}` : "";
				  } else if (item.AccessType === "A") {
					const agentEntry = aAgentData.find(a =>
					  a.AgentBP_BusinessPartnerID === item.BPId &&
					  a.ContractHolderBP_BusinessPartnerID === sCompany
					);
		  
					if (agentEntry) {
					  const company = aCompanyData.find(c => c.BusinessPartnerID === agentEntry.AgentBP_BusinessPartnerID);
					  fullName = company?.Name || "";
					}
				  }
		  
				  return {
					oEnerlineUsersAgents: fullName,
					oAccessType: accessType,
					oTerminationType: terminationLabel,
					oTerminationDate: item.Date,
					selected: true,
					id: item.ID,
					BPId:item.BPId,
					RelationBP: item.RelationBP

				  };
				});
		  
			  // Optionally set to model for table binding
			  //const oJSONModel = new sap.ui.model.json.JSONModel({ terminationUser: result });
			  //this.setModel(oJSONModel, "terminationModel");

			const oAccessFutTermModel = new sap.ui.model.json.JSONModel(result);
			oAccessFutTermModel.setSizeLimit(1000);
			this.getOwnerComponent().setModel(oAccessFutTermModel, "terminationModel");
				console.log("oAccessFutTermModel", oAccessFutTermModel);
			  return oAccessFutTermModel;
		  
			} catch (err) {
			  console.error("❌ Error fetching terminations:", err);
			  return [];
			}
		  },

		  //end model
   
		_bindDynamicTerminationTable: function (sSelectedTabKey) {
			const oShellModel = this.getOwnerComponent().getModel("sCompanySelc");
			const sBPID = oShellModel?.getProperty("/selectedCompany");
			const sCompany = sBPID? sBPID : "7000000001";

			const oVBox = this.byId("oTerminationContainer");
			this.fetchUpcomingTerminations(sCompany);
			//sap.ui.core.BusyIndicator.show(0);
			//oVBox.removeAllItems();
		 
			const oTable = new sap.m.Table(this.createId("otermTable"), {
				columns: [
					new sap.m.Column({ header: null, width: "5rem" }), // placeholder for Select All
					new sap.m.Column({ header: new sap.m.Text({ text: "Enerline Users/Agents" }) }),
					new sap.m.Column({ header: new sap.m.Text({ text: "Access Type" }) }),
					new sap.m.Column({ header: new sap.m.Text({ text: "Termination Type" }) }),
					new sap.m.Column({ header: new sap.m.Text({ text: "Termination Date" }) })
				]
			});
		 
			// Define the template for rows
			const oItemTemplate = new sap.m.ColumnListItem({
				cells: [
					new sap.m.CheckBox({
						select:this.onTerminationCheckboxSelect.bind(this),
						customData: [
							new sap.ui.core.CustomData({
								key: "id",
								value: "{terminationModel>id}"
							})
						]
						
					}),
					new sap.m.Text({ text: "{terminationModel>oEnerlineUsersAgents}" }),
					new sap.m.Text({ text: "{terminationModel>oAccessType}" }),
					new sap.m.Text({ text: "{terminationModel>oTerminationType}" }),
					new sap.m.HBox({
						items: [
							new sap.m.Text({
								text: {
									path: 'terminationModel>oTerminationDate',
									formatter: function (sDate) {
										if (!sDate) return "";
										// Parse string 'YYYY-MM-DD' manually to avoid time zone shift
										const [year, month, day] = sDate.split("-");
										const oDate = new Date(year, month - 1, day); // month is 0-based
										const oFormatter = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "MM/dd/yyyy" });
										return oFormatter.format(oDate);
									  }
								}
							}),
							new sap.m.DatePicker({
								value: "{terminationModel>oTerminationDate}",
								visible: false,
								valueFormat: "yyyy-MM-dd",
								displayFormat: "long"
							})
						]
					})
				]
			});
			//sap.ui.core.BusyIndicator.hide();
			// Bind table items to model path
			oTable.bindItems({
				path: "terminationModel>/",
				template: oItemTemplate
			});
		 
			const that = this; // capture context for inner function
 
			const oSelectAllCheckBox = new sap.m.CheckBox({
				select: function (oEvent) {
					const bSelected = oEvent.getParameter("selected");
					const aItems = oTable.getItems();
			
					aItems.forEach(function (oItem) {
						const oCheckBox = oItem.getCells()[0];
						const oHBox = oItem.getCells()[4];
						const aControls = oHBox.getItems();
						const bEditModeId = that.byId("oEditTermId");
							
							const bEditMode = that._bEditMode;
							console.log(bSelected, bEditMode, bEditModeId.getEnabled());
						oCheckBox.setSelected(bSelected);
						if (bSelected && bEditMode === false && bEditModeId.getEnabled() === false) {
						aControls[0].setVisible(bSelected); // Text
						aControls[1].setVisible(!bSelected);  // DatePicker
						bEditModeId.setEnabled(true);
						console.log("test 1");
						} else if (bSelected && bEditMode === true && bEditModeId.getEnabled() === false) {
						aControls[0].setVisible(bSelected); // Text
						aControls[1].setVisible(!bSelected);  // DatePicker
						bEditModeId.setEnabled(true);
						console.log("test 12");
						} else if (!bSelected && bEditMode === true && bEditModeId.getEnabled() === false) {
						aControls[0].setVisible(!bSelected); // Text
						aControls[1].setVisible(bSelected);  // DatePicker
						bEditModeId.setEnabled(false);
						console.log("test 123");
						} else if (bSelected && bEditMode === false && bEditModeId.getEnabled() === true) {
						aControls[0].setVisible(bSelected); // Text
						aControls[1].setVisible(!bSelected);  // DatePicker
						console.log("test 112345");
						} else if (bSelected && bEditMode === true && bEditModeId.getEnabled() === true) {
						aControls[0].setVisible(bSelected); // Text
						aControls[1].setVisible(!bSelected);  // DatePicker
						console.log("test 1123456");
						} else {
						aControls[0].setVisible(!bSelected); // Text
						aControls[1].setVisible(bSelected);  // DatePicker
						bEditModeId.setEnabled(false);
						console.log("test 11234");
						}
					});
			
					
				}
			});
		 
			// Set Select All checkbox in header
			oTable.getColumns()[0].setHeader(oSelectAllCheckBox);
		 // ✅ Enable Edit button only if checkboxes are selected
		 const oEditButton = that.byId("oEditTermId");
		 if (oEditButton) {
			 oEditButton.setEnabled(false); // enable if select-all is true, else disable
		 }
			// Add table to the VBox
			//oVBox.removeAllItems();
			//oVBox.addItem(oTable);
			oVBox.addContent(oTable);
		},
		//End Termination
		_handleTabChange: async function (sSelectedTabKey) {

			this._bindDynamicTable(sSelectedTabKey);

			const oPageIdMap = {
				"tab1": "container6",
				"tab2": "container1",
				"tab3": "container2",
				
			};

			console.log('slectKey on page', sSelectedTabKey);
			
			const sPageId = oPageIdMap[sSelectedTabKey];
			if (!sPageId) return;
			console.log('Page Loading', sPageId);

			const oTargetPage = this.byId(sPageId);

			let oFCL = this.byId("fcl"); // Always same ID

			if (!oFCL) {
				// Create FCL once if not already created
				oFCL = new sap.f.FlexibleColumnLayout({
					id: this.createId("fcl"),
					layout: sap.f.LayoutType.TwoColumnsMidExpanded,
					backgroundDesign: "Translucent",
					stateChange: this.onStateChanged.bind(this)
				});
			} else {
				const oOldParent = oFCL.getParent();
				if (oOldParent && oOldParent !== oTargetPage) {
					console.log("loading remove");
					oOldParent.removeContent(oFCL);
				}
			}

			// Add to selected tab's container page
			if (!oFCL.getParent()) {
				console.log("loading remove");
				oTargetPage.addContent(oFCL);
			}
			//this._bindDynamicTable(sSelectedTabKey);
		},

		onTaabSelect: async function (oEvent) {// Perform any necessary updates after rendering
			//this._onMobileView(this);
			const oRouter = this.getOwnerComponent().getRouter();
			const bIsPhone = sap.ui.Device.system.phone; // Works even in browser device emulation
		  
			//let sLayout = "OneColumn"; // default for phone
		  
			if (bIsPhone) {
			  // Use semantic helper layout for larger devices
			 let sLayout = "OneColumn";
			  oRouter.navTo("list", {
				layout: sLayout,
				oBPid: this._oBPid || 0,
				tab: this.oTabPath || "enerlineUsers"
			  });
			}
			//console.log(this._oBPid,"detailsoRouter>>>", this.oTabPath);

			const oIconTabBar = this.byId('idTabBar');
			const sSelectedKey = oIconTabBar.getSelectedKey();
			const otermTable = sSelectedKey === "tab5" ? this._bindDynamicTerminationTable(sSelectedKey) : this._handleTabChange(sSelectedKey);
			//this._handleTabChange(sSelectedKey);
		}
	});
});
