sap.ui.define([
	"cmmaccessadminrights/cmmaccessadminrights/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
