/* global QUnit */

sap.ui.require(["cmmaccessadminrights/cmmaccessadminrights/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
